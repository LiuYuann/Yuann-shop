<?php
/* Smarty version 3.1.32, created on 2018-06-22 13:01:41
  from 'C:\wamp64\www\mine\application\index\view\productdetail\productdetail.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b2c82b5c26786_87182298',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a4840f0dcde90956bb684f28e462d200e5aadc2c' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\index\\view\\productdetail\\productdetail.html',
      1 => 1529642675,
      2 => 'file',
    ),
    '6e1452b4c661213e182963508266af1b04b388d2' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\public\\model.html',
      1 => 1529643556,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:model.html' => 1,
  ),
),false)) {
function content_5b2c82b5c26786_87182298 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_209345b2c82b581cc98_73708079', "span9");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "model.html", '6e1452b4c661213e182963508266af1b04b388d2', 'content_5b2c82b5611c10_72613370');
}
/* {block "span9"} */
class Block_209345b2c82b581cc98_73708079 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'span9' => 
  array (
    0 => 'Block_209345b2c82b581cc98_73708079',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="span9">
    <ul class="breadcrumb">
    <li><a href="__ROOT__/index.php/index/">主页</a> <span class="divider">/</span></li>
    <li><a href="__ROOT__/index.php/index/products/index">商品</a> <span class="divider">/</span></li>
    <li class="active">商品详情</li>
    </ul>	
	<div class="row">	  
			<div id="gallery" class="span3">
            <a href="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/1.jpg" title="Fujifilm FinePix S2950 Digital Camera">
				<img src="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/1.jpg" style="width:100%" alt="Fujifilm FinePix S2950 Digital Camera"/>
            </a>
			<div id="differentview" class="moreOptopm carousel slide">
                <div class="carousel-inner">
                  <div class="item active">
                   <a href="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/1.jpg"> <img style="width:30%" src="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/1.jpg" alt="商品图片"/></a>
                   <a href="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/2.jpg"> <img style="width:30%" src="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/2.jpg" alt="商品图片"/></a>
                   <a href="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/3.jpg" > <img style="width:30%" height="87" width="87"src="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/3.jpg" alt="商品图片"/></a>
                  </div>
                  <div class="item">
                   <a href="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/1.jpg" > <img style="width:29%" src="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/1.jpg" alt="商品图片"/></a>
                   <a href="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/2.jpg"> <img style="width:29%" src="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/2.jpg" alt="商品图片"/></a>
                   <a href="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/3.jpg"> <img style="width:29%" src="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['data']->value['thumb'];?>
/3.jpg" alt="商品图片"/></a>
                  </div>
                </div>
              <!--  
			  <a class="left carousel-control" href="#myCarousel" data-slide="prev">‹</a>
              <a class="right carousel-control" href="#myCarousel" data-slide="next">›</a> 
			  -->
              </div>
			  
			 <div class="btn-toolbar">
			  <div class="btn-group">
				<span class="btn"><i class="icon-envelope"></i></span>
				<span class="btn" ><i class="icon-print"></i></span>
				<span class="btn" ><i class="icon-zoom-in"></i></span>
				<span class="btn" ><i class="icon-star"></i></span>
				<span class="btn" ><i class=" icon-thumbs-up"></i></span>
				<span class="btn" ><i class="icon-thumbs-down"></i></span>
			  </div>
			</div>
			</div>
			<div class="span6">
				<h3><?php echo $_smarty_tpl->tpl_vars['data']->value['gname'];?>
  </h3>
				<small>- (14MP, 18x Optical Zoom) 3-inch LCD</small>
				<hr class="soft"/>
				<form class="form-horizontal qtyFrm" method="post" action="__ROOT__/index.php/index/productdetail/addTocart">
				  <div class="control-group">
					<label class="control-label"><span>￥<?php echo $_smarty_tpl->tpl_vars['data']->value['price'];?>
</span></label>
					<div class="controls">
					<input type="number" min="1" class="span1" placeholder="1" name='num' value='1'/>
					<input type="hidden" name="gid" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['gid'];?>
"/>
					  <button type="submit" class="btn btn-large btn-primary pull-right" name='add'> 加入购物车 <i class=" icon-shopping-cart"></i></button>
					</div>
				  </div>
				</form>
				
				<hr class="soft"/>
				<?php if ($_smarty_tpl->tpl_vars['data']->value['discount']) {?>
				<h3 style="color:red; font-weight:bold;">折扣：￥<?php echo $_smarty_tpl->tpl_vars['data']->value['discount'];?>
 </h3>
				<?php }?>
				<h4>剩余库存：<?php echo $_smarty_tpl->tpl_vars['data']->value['stock'];?>
 件</h4>
				<h4>销量：<?php echo $_smarty_tpl->tpl_vars['data']->value['sales'];?>
 件</h4>
				
				<form class="form-horizontal qtyFrm pull-right">
				  <div class="control-group">
					<label class="control-label"><span>规格</span></label>
					<div class="controls">
					  <select class="span2">
					  	  <option>畅玩版</option>
						  <option>青春版</option>
						  <option>旗舰版</option>
						  <option>尊享版</option>
						</select>
					</div>
				  </div>
				</form>
				<hr class="soft clr"/>
				<p>
				<?php echo implode(" ",$_smarty_tpl->tpl_vars['data']->value['description']);?>

				
				</p>
				<a class="btn btn-small pull-right" href="#detail">更多详情</a>
				<br class="clr"/>
			<a href="#" name="detail"></a>
			<hr class="soft"/>
			</div>
			
			<div class="span9">
            <ul id="productDetail" class="nav nav-tabs">
              <li class="active"><a href="#home" data-toggle="tab">商品详情</a></li>
              <li><a href="#profile" data-toggle="tab">相关商品</a></li>
            </ul>
            <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade active in" id="home">
			  <h4>商品详情</h4>
                <table class="table table-bordered">
				<tbody>
				<tr class="techSpecRow"><th colspan="2">具体信息</th></tr>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value['description'], 'd');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['d']->value) {
?>
				<tr class="techSpecRow"><td class="techSpecTD1"><?php echo $_smarty_tpl->tpl_vars['d']->value;?>
 </td></tr>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</tbody>
				</table>
				
				
              </div>
		<div class="tab-pane fade" id="profile">
		<div id="myTab" class="pull-right">
		 <a href="#listView" data-toggle="tab"><span class="btn btn-large"><i class="icon-list"></i></span></a>
		 <a href="#blockView" data-toggle="tab"><span class="btn btn-large btn-primary"><i class="icon-th-large"></i></span></a>
		</div>
		<br class="clr"/>
		<hr class="soft"/>
		<div class="tab-content">
			<div class="tab-pane" id="listView">
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['related']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
				<div class="row">	  
					<div class="span2">
					<img src="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['row']->value['thumb'];?>
/1.jpg" alt=""/>
					</div>
					<div class="span4">
						<h3><?php echo $_smarty_tpl->tpl_vars['row']->value['gname'];?>
</h3>				
						<hr class="soft"/>
						<p>
						<?php echo $_smarty_tpl->tpl_vars['row']->value['description'];?>

						</p>
						<a class="btn btn-small pull-right" href="__ROOT__/index.php/index/productdetail/index?gid=<?php echo $_smarty_tpl->tpl_vars['row']->value['gid'];?>
">查看</a>
						<br class="clr"/>
					</div>
					<div class="span3 alignR">
						<h3> <?php echo $_smarty_tpl->tpl_vars['row']->value['price'];?>
</h3>
						</label><br/>
						<div class="btn-group">
						<a href="__ROOT__/index.php/index/productdetail/index?gid=<?php echo $_smarty_tpl->tpl_vars['row']->value['gid'];?>
" class="btn btn-large btn-primary"> 加入 <i class=" icon-shopping-cart"></i></a>
						<a href="__ROOT__/index.php/index/productdetail/index?gid=<?php echo $_smarty_tpl->tpl_vars['row']->value['gid'];?>
" class="btn btn-large"><i class="icon-zoom-in"></i></a>
						</div>
					</div>
			</div>
			<hr class="soft"/>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</div>
			<div class="tab-pane active" id="blockView">
				<ul class="thumbnails">
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['related']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
					<li class="span3">
					  <div class="thumbnail">
						<a href="__ROOT__/index.php/index/productdetail/index?gid=<?php echo $_smarty_tpl->tpl_vars['row']->value['gid'];?>
"><img src="__STATIC__/imgs/<?php echo $_smarty_tpl->tpl_vars['row']->value['thumb'];?>
/1.jpg" alt="" width='160' height='160'/></a>
						<div class="caption">
						  <h5><?php echo $_smarty_tpl->tpl_vars['row']->value['gname'];?>
</h5>
						  <p> 
							销量：<?php echo $_smarty_tpl->tpl_vars['row']->value['sales'];?>
 
						  </p>
						  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail/index?gid=<?php echo $_smarty_tpl->tpl_vars['row']->value['gid'];?>
"> <i class="icon-zoom-in"></i></a> <a class="btn" href="#">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">&euro;<?php echo $_smarty_tpl->tpl_vars['row']->value['price'];?>
 </a></h4>
						</div>
					  </div>
					</li>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				  </ul>
			<hr class="soft"/>
			</div>
		</div>
				<br class="clr">
					 </div>
		</div>
          </div>
	</div>
</div>




<?php
}
}
/* {/block "span9"} */
/* Start inline template "C:\wamp64\www\mine\public\model.html" =============================*/
function content_5b2c82b5611c10_72613370 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<html lang="en"><head>
    <meta charset="utf-8">
    <title>Yuann shop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">	
<!-- Bootstrap style --> 
    <link id="callCss" rel="stylesheet" href="__STATIC__/themes/bootshop/bootstrap.min.css" media="screen">
    <link href="__STATIC__/themes/css/base.css" rel="stylesheet" media="screen">
<!-- Bootstrap style responsive -->	
	<link href="__STATIC__/themes/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="__STATIC__/themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->	
	<link href="__STATIC__/themes/js/google-code-prettify/prettify.css" rel="stylesheet">
<!-- fav and touch icons -->
    <link rel="shortcut icon" href="__STATIC__/themes/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="__STATIC__/themes/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="__STATIC__/themes/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="__STATIC__/themes/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="__STATIC__/themes/images/ico/apple-touch-icon-57-precomposed.png">
	<style type="text/css" id="enject"></style>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery-3.3.1.js" type="text/javascript"><?php echo '</script'; ?>
>
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_188595b2c82b56327b2_23645149', "style");
?>

  </head>
<body>
<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
	<div class="span6">
	欢迎<strong> <?php echo session('user');?>
</strong>
	<a href="__ROOT__/index.php/index/login/logout"><span class="btn btn-mini btn-primary">退出登录  </span> </a> 
	</div>
	<div class="span6">
	<div class="pull-right cart-data">
		<a href="__ROOT__/index.php/index/record"><span class="btn btn-mini "><i class="icon-shopping-cart icon-white"></i> 购买记录  </span></a>
		<span class="btn btn-mini sum">￥<?php echo session('sum');?>
</span>
		<a href="__ROOT__/index.php/index/login"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> 购物车  </span> </a> 
	</div>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" href="__ROOT__/index.php/index/"><img src="__STATIC__/themes/images/logo.png" alt="Bootsshop"></a>
		<form class="form-inline navbar-search" method="get" action="__ROOT__/index.php/index/products">
		<input id="srchFld" class="srchTxt" name='key' type="text" style="width:200px;height:30px">
		  <select class="srchTxt" name='factor'>
			<option value='所有'>所有</option>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, session('kinds'), 'value', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
			<option value='<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
'><?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</option>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            
		</select> 
		  <button type="submit" id="submitButton" name='search' class="btn btn-primary">搜索</button>
    </form>
    <ul id="topMenu" class="nav pull-right">
	 <li class=""><a href="__ROOT__/index.php/index/specialoffer">特价优惠</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/transfer">物流详情</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/contact">联系我</a></li>
	 <li class="">
	 <a href="__ROOT__/index.php/index/login" role="button"  style="padding-right:0"><span class="btn btn-large btn-success">登录</span></a>
	</li>
    </ul>
  </div>
</div>
</div>
</div>
<!-- Header End====================================================================== -->

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_102485b2c82b56eb138_47182002', "carouselBlk");
?>


<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<div id="sidebar" class="span3">
		<div class="well well-small cart-data"><a id="myCart"  href="__ROOT__/index.php/index/login"><img src="__STATIC__/themes/images/ico-cart.png" alt="cart"><span class='count'><?php echo session('count');?>
种商品</span>  <span class="badge badge-warning pull-right sum"><span class='sum'>￥<?php echo session('sum');?>
</span></span></a></div>
		<br>
		<ul id="sideManu" class="nav nav-tabs nav-stacked">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, session('kinds'), 'value', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
			<li class="subMenu open"><a> <?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</a>
				<ul>
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['value']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
						<li><a href="__ROOT__/index.php/index/products?cid=<?php echo $_smarty_tpl->tpl_vars['row']->value['cid'];?>
"><i class="icon-chevron-right"></i><?php echo $_smarty_tpl->tpl_vars['row']->value['cname'];?>
</a></li>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</ul>
			</li>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ul>
		<br>
		<br>
			<div class="thumbnail">
			<h4 style='text-align:center; color:red;'>销量冠军</h4>
				<img src="__STATIC__/imgs/computer/peripherals/45140873352/1.jpg" title="Bootshop New Kindel" alt="Bootshop Kindel">
				<div class="caption">
				  <h5>陈子豪外设店宜博M639电竞机械鼠标电脑有线吃鸡游戏宏绝地求生</h5>
				    <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail/index?gid=45140873352"> <i class="icon-zoom-in"></i></a> <a class="btn" href="productdetail?gid=45140873352">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="productdetail?gid=45140873352">￥107</a></h4>
				</div>
			  </div><br><br>
			<div class="thumbnail">
				<img src="__STATIC__/themes/images/payment_methods.png" title="Bootshop 支付方式" alt="Payments Methods">
				<div class="caption">
				  <h5>支付方式</h5>
				</div>
			  </div>
	</div>
<!-- Sidebar end=============================================== -->
		
		
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_111695b2c82b57ccae5_58501514', "span9");
?>

		
		</div>
	</div>
</div>
<!-- Footer ================================================================== -->
	<div id="footerSection">
	<div class="container">
		<div class="row">
			<div class="span3">
				<h4>账户</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/login">你的账户</a>
				<a href="__ROOT__/index.php/index/login">个人信息</a> 
				<a href="__ROOT__/index.php/index/login">收货地址</a> 
				<a href="__ROOT__/index.php/index/specialoffer">折扣信息</a>  
				<a href="__ROOT__/index.php/index/record">购买记录</a>
			 </div>
			<div class="span3">
				<h4>信息</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/contact">联系我们</a>  
				<a href="__ROOT__/index.php/index/register">注册</a>  
				<a href="__ROOT__/index.php/index/legalnotice">法律信息</a>  
				<a href="__ROOT__/index.php/index/tac">条款和条件</a> 
				<a href="__ROOT__/index.php/index/faq">常问问题</a>
			 </div>
			<div class="span3">
				<h4>优惠</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/index">新款商品</a> 
				<a href="__ROOT__/index.php/index/index">畅销品</a>  
				<a href="__ROOT__/index.php/index/specialoffer">特别优惠</a>  
				<a href="#">生产商</a> 
				<a href="#">供应商</a> 
			 </div>
			<div id="socialMedia" class="span3 pull-right">
				<h4>社交媒体 </h4>
			<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;'>
		<img class='1' style='display:none;position:absolute;top:-30px;' width="100" height="100" src="__STATIC__/themes/images/qqma.jpg"/>
	</div>
&nbsp;&nbsp;<img class='2' width="60"  height="60" src="__STATIC__/themes/images/qq.png" title="QQ" alt="QQ"/>
</div>
<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;' >
		<img width="100" height="100" class='3' style='display:none;position:absolute;top:-30px;' src="__STATIC__/themes/images/weixinma.png"/>
	</div>

&nbsp;&nbsp;<img width="60" class='4' height="60" src="__STATIC__/themes/images/weixin.png" title="微信" alt="微信"/>
</div>
<div style='float:left;'>
&nbsp;&nbsp;&nbsp;<br><br><br><br><br><a href="https://weibo.com/u/5703804590"><img width="60" height="60" src="__STATIC__/themes/images/weibo.png" title="微博" alt="微博"/></a> 
</div>

                <?php echo '<script'; ?>
>  
                $(document).ready(function(){  
                    $(".2").mouseover(function(){
                    $(".1").show();}); 
                    $(".2").mouseout(function(){$(".1").hide();});
                    $(".4").mouseover(function(){$(".3").show();});  
                    $(".4").mouseout(function(){$(".3").hide();});
                });   
                <?php echo '</script'; ?>
>  
		 </div>
         
	</div><!-- Container End -->
	</div>
</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/google-code-prettify/prettify.js"><?php echo '</script'; ?>
>
	
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/bootshop.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery.lightbox-0.5.js"><?php echo '</script'; ?>
>
	
	<!-- Themes switcher section ============================================================================================= -->
<div id="secectionBox">
<link rel="stylesheet" href="__STATIC__/themes/switch/themeswitch.css" type="text/css" media="screen">
	<div id="themeContainer">
	<div id="hideme" class="themeTitle">主题更改</div>
	<div class="themeName">默认 主题</div>
	<div class="images style">
	<a href="__STATIC__/themes/css/#" name="bootshop"><img src="__STATIC__/themes/switch/images/clr/bootshop.png" alt="bootstrap business templates" class="active"></a>
	<a href="__STATIC__/themes/css/#" name="businessltd"><img src="__STATIC__/themes/switch/images/clr/businessltd.png" alt="bootstrap business templates" class=""></a>
	</div>
	<div class="themeName">皮肤</div>
	<div class="images style">
		<a href="__STATIC__/themes/css/#" name="amelia" title="Amelia"><img src="__STATIC__/themes/switch/images/clr/amelia.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="spruce" title="Spruce"><img src="__STATIC__/themes/switch/images/clr/spruce.png" alt="bootstrap business templates" class=""></a>
		<a href="__STATIC__/themes/css/#" name="superhero" title="Superhero"><img src="__STATIC__/themes/switch/images/clr/superhero.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cyborg"><img src="__STATIC__/themes/switch/images/clr/cyborg.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cerulean"><img src="__STATIC__/themes/switch/images/clr/cerulean.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="journal"><img src="__STATIC__/themes/switch/images/clr/journal.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="readable"><img src="__STATIC__/themes/switch/images/clr/readable.png" alt="bootstrap business templates"></a>	
		<a href="__STATIC__/themes/css/#" name="simplex"><img src="__STATIC__/themes/switch/images/clr/simplex.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="slate"><img src="__STATIC__/themes/switch/images/clr/slate.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="spacelab"><img src="__STATIC__/themes/switch/images/clr/spacelab.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="united"><img src="__STATIC__/themes/switch/images/clr/united.png" alt="bootstrap business templates"></a>
		<p style="margin:0;line-height:normal;margin-left:-10px;display:none;"><small>These are just examples and you can build your own color scheme in the backend.</small></p>
	</div>
	<div class="themeName">背景颜色 </div>
	<div class="images patterns">
		<a href="__STATIC__/themes/css/#" name="pattern1"><img src="__STATIC__/themes/switch/images/pattern/pattern1.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="pattern2"><img src="__STATIC__/themes/switch/images/pattern/pattern2.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern3"><img src="__STATIC__/themes/switch/images/pattern/pattern3.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern4"><img src="__STATIC__/themes/switch/images/pattern/pattern4.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern5"><img src="__STATIC__/themes/switch/images/pattern/pattern5.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern6"><img src="__STATIC__/themes/switch/images/pattern/pattern6.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern7"><img src="__STATIC__/themes/switch/images/pattern/pattern7.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern8"><img src="__STATIC__/themes/switch/images/pattern/pattern8.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern9"><img src="__STATIC__/themes/switch/images/pattern/pattern9.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern10"><img src="__STATIC__/themes/switch/images/pattern/pattern10.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern11"><img src="__STATIC__/themes/switch/images/pattern/pattern11.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern12"><img src="__STATIC__/themes/switch/images/pattern/pattern12.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern13"><img src="__STATIC__/themes/switch/images/pattern/pattern13.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern14"><img src="__STATIC__/themes/switch/images/pattern/pattern14.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern15"><img src="__STATIC__/themes/switch/images/pattern/pattern15.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern16"><img src="__STATIC__/themes/switch/images/pattern/pattern16.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern17"><img src="__STATIC__/themes/switch/images/pattern/pattern17.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern18"><img src="__STATIC__/themes/switch/images/pattern/pattern18.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern19"><img src="__STATIC__/themes/switch/images/pattern/pattern19.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern20"><img src="__STATIC__/themes/switch/images/pattern/pattern20.png" alt="bootstrap business templates"></a>
		 
	</div>
	</div>	
</div>
<?php echo '<script'; ?>
 type="text/javascript">
jQuery(document).ready(function() {
// Pattern Selector function//////////////////////////////////	
	jQuery('.patterns a').click(function(e) {
		e.preventDefault();
			jQuery(this).parent().find('img').removeClass('active');
			jQuery(this).find('img').addClass('active');

			var name = jQuery(this).attr('name');
			
				jQuery('body').css('background', 'url(__STATIC__/themes/switch/images/pattern/'+name+'.png) repeat center center scroll');
				jQuery('body').css('background-size', 'auto');
	});
// Style Selector function ////////////////////////////////////
	jQuery('.style a').click(function(e) {
		e.preventDefault();
		jQuery(this).parent().find('img').removeClass('active');
		jQuery(this).find('img').addClass('active');

		var name = jQuery(this).attr('name');

		if(name == 'green') {
			jQuery('#callCss').attr('href', '');
		} else {
			jQuery('#callCss').attr('href', 'http://localhost:8080/mine/public/static/themes/'+name+'/bootstrap.min.css');
		}

	});
	
	/* Settings Button */
	$('#themesBtn').click(function() {
	  $('#secectionBox').animate({
		right:'0'
	  }, 500, function() {
		// Animation complete.
	  });
	  $('#themesBtn').animate({
		right:'-80'
	  }, 100, function() {
		// Animation complete.
	  });
	}); 


	$('#hideme').click(function() {
		$('#secectionBox').animate({
		right:'-999'
	  }, 500, function() {
		// Animation complete.
	  });
	  
	  $('#themesBtn').animate({
		right:'0'
	  }, 700, function() {
		// Animation complete.
	  }); 
	});

});
<?php echo '</script'; ?>
>
<span id="themesBtn"></span>
</body></html><?php
}
/* {block "style"} */
class Block_188595b2c82b56327b2_23645149 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_188595b2c82b56327b2_23645149',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "style"} */
/* {block "carouselBlk"} */
class Block_102485b2c82b56eb138_47182002 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'carouselBlk' => 
  array (
    0 => 'Block_102485b2c82b56eb138_47182002',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "carouselBlk"} */
/* {block "span9"} */
class Block_111695b2c82b57ccae5_58501514 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'span9' => 
  array (
    0 => 'Block_111695b2c82b57ccae5_58501514',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

	<?php
}
}
/* {/block "span9"} */
/* End inline template "C:\wamp64\www\mine\public\model.html" =============================*/
}
