<?php
/* Smarty version 3.1.32, created on 2018-06-12 08:42:56
  from 'C:\wamp64\www\mine\application\admin\view\showgoods\Goods-index.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1f17101155f7_63988971',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'daf4cfe567af3524aa305d2a07f25f0481392509' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\admin\\view\\showgoods\\Goods-index.html',
      1 => 1528616051,
      2 => 'file',
    ),
    '5823787c55a2f03a73aa2d624b845693b45b0708' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\public\\adminmodel.html',
      1 => 1528621739,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:adminmodel.html' => 1,
  ),
),false)) {
function content_5b1f17101155f7_63988971 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_144435b1f170fca6768_93887597', "data");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "adminmodel.html", '5823787c55a2f03a73aa2d624b845693b45b0708', 'content_5b1f170fb94e24_87264796');
}
/* {block "data"} */
class Block_144435b1f170fca6768_93887597 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'data' => 
  array (
    0 => 'Block_144435b1f170fca6768_93887597',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div id="content">
		<div class="item"><div class="title">商品列表</div>
<div class="data-list clear">
<form action="" class="form-horizontal">
	请选择商品分类：
	<select name="cid" onchange="check(this.value);">
	<option value="所有">所有</option>
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['kinds']->value, 'value', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
		<option value="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</option>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['value']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
			<option value="<?php echo $_smarty_tpl->tpl_vars['row']->value['cid'];?>
">----<?php echo $_smarty_tpl->tpl_vars['row']->value['cname'];?>
</option>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</select>
	请选择排序方式：
	<select name="order" onchange="check(this.value);">
		<option value='1'>新品</option>
        <option value='2'>价格升序</option>
        <option value='3'>价格降序</option>
        <option value='4'>销量由高到低</option>
	</select>
	<button type='submit'>确定</button>
</form>
	
	<table border="1" style="text-align:center;">
		<tr><th width="80">商品编号</th><th>商品名</th><th width="80">上架</th><th width="120">操作</th></tr>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['goods']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
		<tr class="item">
			<td><?php echo $_smarty_tpl->tpl_vars['row']->value['gid'];?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['row']->value['gname'];?>
</td>
			<td class="center">
			<a href="#">
			<?php if ($_smarty_tpl->tpl_vars['row']->value['status'] == 'yes') {?>
			<?php echo '是';?>

			<?php } else { ?>
			<?php echo '否';?>

			<?php }?>
			</a>
			</td>
			<td class="center"><a href="__ROOT__/index.php/admin/showgoods/editgoods?gid=<?php echo $_smarty_tpl->tpl_vars['row']->value['gid'];?>
">修改</a> 
			<a class='del' gid="<?php echo $_smarty_tpl->tpl_vars['row']->value['gid'];?>
" style="cursor: pointer;">删除</a></td></tr>
		</tr>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>	
	</table>
	<div class="pagination">
	<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

	<br class="clr"/>
</div>
</div>
</div>
</div>
<?php echo '<script'; ?>
 type="text/javascript">
	$(".del").each(function(){   //删除购物车商品
			$(this).click(function(i){
			$gid=$(this).attr("gid");
			$item=$(this).closest(".item");
				if(confirm("你确定要删除吗？")){					
					$.ajax({
	                        url: "__ROOT__/index.php/admin/showgoods/delgoods",
	                        data: { "gid":$gid,},
	                        dataType:"json",
	                        success: function (msg) {
	                        	if (msg!=0){
	                        	console.log(msg);
	                        		$item.remove();                       		
	                        	}
	                        },
	                    });
					}
				});
		});
<?php echo '</script'; ?>
>
<?php
}
}
/* {/block "data"} */
/* Start inline template "C:\wamp64\www\mine\public\adminmodel.html" =============================*/
function content_5b1f170fb94e24_87264796 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>后台管理系统</title>
	<link rel="shortcut icon" href="__STATIC__/themes/images/ico/favicon.ico">
	<link id="callCss" rel="stylesheet" href="__STATIC__/bootstrap/css/bootstrap.min.css" media="screen">
	<link href="__STATIC__/admin/css/admin.css" rel="stylesheet" />
	<?php echo '<script'; ?>
 src="__STATIC__/admin/js/jquery-3.3.1.js"><?php echo '</script'; ?>
>
</head>
<body>
<div id="top">
	<h1 class="left">后台管理系统</h1>
	<ul class="right">
		<li>欢迎您&nbsp;<?php echo session('admin_name');?>
</li>
		<li>|</li><li><a href="__ROOT__/index.php/index/index/index" target="_blank">前台首页</a></li>
		<li>|</li><li><a href="__ROOT__/index.php/admin/login/logout">退出登录</a></li>
	</ul>
</div>
<div id="main">
	<div id="menu" class="left">
		<ul><li><a href="__ROOT__/index.php/admin/index/index" id="Index_index">后台首页</a></li>
			<li><a href="__ROOT__/index.php/admin/addgoods/index" id="Goods_add">商品添加</a></li>
			<li><a href="__ROOT__/index.php/admin/showgoods/index?order=1" id="Goods_index">商品列表</a></li>
			<li><a href="__ROOT__/index.php/admin/category/index" id="Category_index">商品分类</a></li>
			<li><a href="__ROOT__/index.php/admin/member/index" id="Member_index">会员管理</a></li>
		</ul>
	</div>
	  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_86345b1f170fc20d99_08360212', "data");
?>

	
</div>
</body>
</html><?php
}
/* {block "data"} */
class Block_86345b1f170fc20d99_08360212 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'data' => 
  array (
    0 => 'Block_86345b1f170fc20d99_08360212',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "data"} */
/* End inline template "C:\wamp64\www\mine\public\adminmodel.html" =============================*/
}
