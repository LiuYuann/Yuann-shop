<?php
/* Smarty version 3.1.32, created on 2018-06-10 14:21:43
  from 'C:\wamp64\www\mine\application\admin\view\discountgoods\discountgoods.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1cc377640554_96193762',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2b6fc11e3397cab0dc1e4ff720957b272e168a4a' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\admin\\view\\discountgoods\\discountgoods.html',
      1 => 1528611624,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b1cc377640554_96193762 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
  <head>
    <title>discountgoods.html</title>
	
    <meta name="keywords" content="keyword1,keyword2,keyword3">
    <meta name="description" content="this is my page">
    <meta name="content-type" content="text/html; charset=UTF-8">
    
    <!--<link rel="stylesheet" type="text/css" href="./styles.css">-->

  </head>
  
  <body>
    This is my HTML page. <br>
  </body>
</html>
<?php }
}
