<?php
/* Smarty version 3.1.32, created on 2018-06-11 22:39:06
  from 'C:\wamp64\www\mine\application\index\view\contact\contact.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1e898a212a73_07594423',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '310696c952e958b78c8570049ef686caca8b60a9' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\index\\view\\contact\\contact.html',
      1 => 1527934712,
      2 => 'file',
    ),
    '6e1452b4c661213e182963508266af1b04b388d2' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\public\\model.html',
      1 => 1528727486,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:model.html' => 1,
  ),
),false)) {
function content_5b1e898a212a73_07594423 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_26475b1e898a1dd5c6_19801532', "style");
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_64685b1e898a1fd930_55275587', "span9");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "model.html", '6e1452b4c661213e182963508266af1b04b388d2', 'content_5b1e8989f2c689_58841644');
}
/* {block "style"} */
class Block_26475b1e898a1dd5c6_19801532 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_26475b1e898a1dd5c6_19801532',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript">
 window.onload = function(){ 
　　$('#sidebar').remove();  
} 	
<?php echo '</script'; ?>
>
<?php
}
}
/* {/block "style"} */
/* {block "span9"} */
class Block_64685b1e898a1fd930_55275587 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'span9' => 
  array (
    0 => 'Block_64685b1e898a1fd930_55275587',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<hr class="soften">
	<h1>联系我们</h1>
	<hr class="soften"/>	
	<div class="row">
		<div class="span4">
		<h4>详细信息</h4>
		<p>	江西师范大学（瑶湖校区）,<br/> 330022, PRC
			<br/><br/>
			1903554839@qq.com<br/>
			﻿Tel 123-456-6780<br/>
			Fax 123-456-5679<br/>
			web:123456789.com
		</p>		
		</div>
			
		<div class="span4">
		<h4>营业时间</h4>
			<h5> 工作日</h5>
			<p>09:00am - 09:00pm<br/><br/></p>
			<h5>周六</h5>
			<p>09:00am - 07:00pm<br/><br/></p>
			<h5>周日</h5>
			<p>12:30pm - 06:00pm<br/><br/></p>
		</div>
		<div class="span4">
		<h4>邮件</h4>
		<form class="form-horizontal">
        <fieldset>
          <div class="control-group">
           
              <input type="text" placeholder="name" class="input-xlarge"/>
           
          </div>
		   <div class="control-group">
           
              <input type="text" placeholder="email" class="input-xlarge"/>
           
          </div>
		   <div class="control-group">
           
              <input type="text" placeholder="subject" class="input-xlarge"/>
          
          </div>
          <div class="control-group">
              <textarea rows="3" id="textarea" class="input-xlarge"></textarea>
           
          </div>

            <button class="btn btn-large" type="submit">发送</button>

        </fieldset>
      </form>
	</div>
<?php
}
}
/* {/block "span9"} */
/* Start inline template "C:\wamp64\www\mine\public\model.html" =============================*/
function content_5b1e8989f2c689_58841644 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<html lang="en"><head>
    <meta charset="utf-8">
    <title>Yuann shop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">	
<!-- Bootstrap style --> 
    <link id="callCss" rel="stylesheet" href="__STATIC__/themes/bootshop/bootstrap.min.css" media="screen">
    <link href="__STATIC__/themes/css/base.css" rel="stylesheet" media="screen">
<!-- Bootstrap style responsive -->	
	<link href="__STATIC__/themes/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="__STATIC__/themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->	
	<link href="__STATIC__/themes/js/google-code-prettify/prettify.css" rel="stylesheet">
<!-- fav and touch icons -->
    <link rel="shortcut icon" href="__STATIC__/themes/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="__STATIC__/themes/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="__STATIC__/themes/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="__STATIC__/themes/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="__STATIC__/themes/images/ico/apple-touch-icon-57-precomposed.png">
	<style type="text/css" id="enject"></style>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery-3.3.1.js" type="text/javascript"><?php echo '</script'; ?>
>
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_234485b1e898a009c07_72023171', "style");
?>

  </head>
<body>
<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
	<div class="span6">
	欢迎<strong> <?php echo session('user');?>
</strong>
	<a href="__ROOT__/index.php/index/login/logout"><span class="btn btn-mini btn-primary">退出登录  </span> </a> 
	</div>
	<div class="span6">
	<div class="pull-right cart-data">
		<a href="__ROOT__/index.php/index/record"><span class="btn btn-mini "><i class="icon-shopping-cart icon-white"></i> 购买记录  </span></a>
		<span class="btn btn-mini sum">￥<?php echo session('sum');?>
</span>
		<a href="__ROOT__/index.php/index/login"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> 购物车  </span> </a> 
	</div>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" href="__ROOT__/index.php/index/"><img src="__STATIC__/themes/images/logo.png" alt="Bootsshop"></a>
		<form class="form-inline navbar-search" method="get" action="__ROOT__/index.php/index/products">
		<input id="srchFld" class="srchTxt" name='key' type="text" style="width:200px;height:30px">
		  <select class="srchTxt" name='factor'>
			<option value='所有'>所有</option>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, session('kinds'), 'value', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
			<option value='<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
'><?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</option>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            
		</select> 
		  <button type="submit" id="submitButton" name='search' class="btn btn-primary">搜索</button>
    </form>
    <ul id="topMenu" class="nav pull-right">
	 <li class=""><a href="__ROOT__/index.php/index/specialoffer">特价优惠</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/transfer">物流详情</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/contact">联系我</a></li>
	 <li class="">
	 <a href="__ROOT__/index.php/index/login" role="button"  style="padding-right:0"><span class="btn btn-large btn-success">登录</span></a>
	</li>
    </ul>
  </div>
</div>
</div>
</div>
<!-- Header End====================================================================== -->

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_327535b1e898a0b29f5_76868745', "carouselBlk");
?>


<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<div id="sidebar" class="span3">
		<div class="well well-small cart-data"><a id="myCart"  href="__ROOT__/index.php/index/login"><img src="__STATIC__/themes/images/ico-cart.png" alt="cart"><span class='count'><?php echo session('count');?>
件商品</span>  <span class="badge badge-warning pull-right sum"><span class='sum'>￥<?php echo session('sum');?>
</span></span></a></div>
		<br>
		<ul id="sideManu" class="nav nav-tabs nav-stacked">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, session('kinds'), 'value', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
			<li class="subMenu open"><a> <?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</a>
				<ul>
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['value']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
						<li><a href="__ROOT__/index.php/index/products?cid=<?php echo $_smarty_tpl->tpl_vars['row']->value['cid'];?>
"><i class="icon-chevron-right"></i><?php echo $_smarty_tpl->tpl_vars['row']->value['cname'];?>
</a></li>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</ul>
			</li>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ul>
		<br>
		<br>
			<div class="thumbnail">
			<h4 style='text-align:center; color:red;'>销量冠军</h4>
				<img src="__STATIC__/imgs/computer/peripherals/45140873352/1.jpg" title="Bootshop New Kindel" alt="Bootshop Kindel">
				<div class="caption">
				  <h5>陈子豪外设店宜博M639电竞机械鼠标电脑有线吃鸡游戏宏绝地求生</h5>
				    <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail/index?gid=45140873352"> <i class="icon-zoom-in"></i></a> <a class="btn" href="productdetail?gid=45140873352">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="productdetail?gid=45140873352">￥107</a></h4>
				</div>
			  </div><br><br>
			<div class="thumbnail">
				<img src="__STATIC__/themes/images/payment_methods.png" title="Bootshop 支付方式" alt="Payments Methods">
				<div class="caption">
				  <h5>支付方式</h5>
				</div>
			  </div>
	</div>
<!-- Sidebar end=============================================== -->
		
		
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_61025b1e898a189644_54379204', "span9");
?>

		
		</div>
	</div>
</div>
<!-- Footer ================================================================== -->
	<div id="footerSection">
	<div class="container">
		<div class="row">
			<div class="span3">
				<h4>账户</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/login">你的账户</a>
				<a href="__ROOT__/index.php/index/login">个人信息</a> 
				<a href="__ROOT__/index.php/index/login">收货地址</a> 
				<a href="__ROOT__/index.php/index/specialoffer">折扣信息</a>  
				<a href="__ROOT__/index.php/index/record">购买记录</a>
			 </div>
			<div class="span3">
				<h4>信息</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/contact">联系我们</a>  
				<a href="__ROOT__/index.php/index/register">注册</a>  
				<a href="__ROOT__/index.php/index/legalnotice">法律信息</a>  
				<a href="__ROOT__/index.php/index/tac">条款和条件</a> 
				<a href="__ROOT__/index.php/index/faq">常问问题</a>
			 </div>
			<div class="span3">
				<h4>优惠</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/index">新款商品</a> 
				<a href="__ROOT__/index.php/index/index">畅销品</a>  
				<a href="__ROOT__/index.php/index/specialoffer">特别优惠</a>  
				<a href="#">生产商</a> 
				<a href="#">供应商</a> 
			 </div>
			<div id="socialMedia" class="span3 pull-right">
				<h4>社交媒体 </h4>
			<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;'>
		<img class='1' style='display:none;position:absolute;top:-30px;' width="100" height="100" src="__STATIC__/themes/images/qqma.jpg"/>
	</div>
&nbsp;&nbsp;<img class='2' width="60"  height="60" src="__STATIC__/themes/images/qq.png" title="QQ" alt="QQ"/>
</div>
<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;' >
		<img width="100" height="100" class='3' style='display:none;position:absolute;top:-30px;' src="__STATIC__/themes/images/weixinma.png"/>
	</div>

&nbsp;&nbsp;<img width="60" class='4' height="60" src="__STATIC__/themes/images/weixin.png" title="微信" alt="微信"/>
</div>
<div style='float:left;'>
&nbsp;&nbsp;&nbsp;<br><br><br><br><br><a href="https://weibo.com/u/5703804590"><img width="60" height="60" src="__STATIC__/themes/images/weibo.png" title="微博" alt="微博"/></a> 
</div>

                <?php echo '<script'; ?>
>  
                $(document).ready(function(){  
                    $(".2").mouseover(function(){
                    $(".1").show();}); 
                    $(".2").mouseout(function(){$(".1").hide();});
                    $(".4").mouseover(function(){$(".3").show();});  
                    $(".4").mouseout(function(){$(".3").hide();});
                });   
                <?php echo '</script'; ?>
>  
		 </div>
         
	</div><!-- Container End -->
	</div>
</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/google-code-prettify/prettify.js"><?php echo '</script'; ?>
>
	
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/bootshop.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery.lightbox-0.5.js"><?php echo '</script'; ?>
>
	
	<!-- Themes switcher section ============================================================================================= -->
<div id="secectionBox">
<link rel="stylesheet" href="__STATIC__/themes/switch/themeswitch.css" type="text/css" media="screen">
	<div id="themeContainer">
	<div id="hideme" class="themeTitle">主题更改</div>
	<div class="themeName">默认 主题</div>
	<div class="images style">
	<a href="__STATIC__/themes/css/#" name="bootshop"><img src="__STATIC__/themes/switch/images/clr/bootshop.png" alt="bootstrap business templates" class="active"></a>
	<a href="__STATIC__/themes/css/#" name="businessltd"><img src="__STATIC__/themes/switch/images/clr/businessltd.png" alt="bootstrap business templates" class=""></a>
	</div>
	<div class="themeName">皮肤</div>
	<div class="images style">
		<a href="__STATIC__/themes/css/#" name="amelia" title="Amelia"><img src="__STATIC__/themes/switch/images/clr/amelia.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="spruce" title="Spruce"><img src="__STATIC__/themes/switch/images/clr/spruce.png" alt="bootstrap business templates" class=""></a>
		<a href="__STATIC__/themes/css/#" name="superhero" title="Superhero"><img src="__STATIC__/themes/switch/images/clr/superhero.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cyborg"><img src="__STATIC__/themes/switch/images/clr/cyborg.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cerulean"><img src="__STATIC__/themes/switch/images/clr/cerulean.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="journal"><img src="__STATIC__/themes/switch/images/clr/journal.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="readable"><img src="__STATIC__/themes/switch/images/clr/readable.png" alt="bootstrap business templates"></a>	
		<a href="__STATIC__/themes/css/#" name="simplex"><img src="__STATIC__/themes/switch/images/clr/simplex.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="slate"><img src="__STATIC__/themes/switch/images/clr/slate.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="spacelab"><img src="__STATIC__/themes/switch/images/clr/spacelab.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="united"><img src="__STATIC__/themes/switch/images/clr/united.png" alt="bootstrap business templates"></a>
		<p style="margin:0;line-height:normal;margin-left:-10px;display:none;"><small>These are just examples and you can build your own color scheme in the backend.</small></p>
	</div>
	<div class="themeName">背景颜色 </div>
	<div class="images patterns">
		<a href="__STATIC__/themes/css/#" name="pattern1"><img src="__STATIC__/themes/switch/images/pattern/pattern1.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="pattern2"><img src="__STATIC__/themes/switch/images/pattern/pattern2.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern3"><img src="__STATIC__/themes/switch/images/pattern/pattern3.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern4"><img src="__STATIC__/themes/switch/images/pattern/pattern4.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern5"><img src="__STATIC__/themes/switch/images/pattern/pattern5.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern6"><img src="__STATIC__/themes/switch/images/pattern/pattern6.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern7"><img src="__STATIC__/themes/switch/images/pattern/pattern7.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern8"><img src="__STATIC__/themes/switch/images/pattern/pattern8.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern9"><img src="__STATIC__/themes/switch/images/pattern/pattern9.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern10"><img src="__STATIC__/themes/switch/images/pattern/pattern10.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern11"><img src="__STATIC__/themes/switch/images/pattern/pattern11.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern12"><img src="__STATIC__/themes/switch/images/pattern/pattern12.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern13"><img src="__STATIC__/themes/switch/images/pattern/pattern13.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern14"><img src="__STATIC__/themes/switch/images/pattern/pattern14.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern15"><img src="__STATIC__/themes/switch/images/pattern/pattern15.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern16"><img src="__STATIC__/themes/switch/images/pattern/pattern16.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern17"><img src="__STATIC__/themes/switch/images/pattern/pattern17.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern18"><img src="__STATIC__/themes/switch/images/pattern/pattern18.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern19"><img src="__STATIC__/themes/switch/images/pattern/pattern19.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern20"><img src="__STATIC__/themes/switch/images/pattern/pattern20.png" alt="bootstrap business templates"></a>
		 
	</div>
	</div>	
</div>
<?php echo '<script'; ?>
 type="text/javascript">
jQuery(document).ready(function() {
// Pattern Selector function//////////////////////////////////	
	jQuery('.patterns a').click(function(e) {
		e.preventDefault();
			jQuery(this).parent().find('img').removeClass('active');
			jQuery(this).find('img').addClass('active');

			var name = jQuery(this).attr('name');
			
				jQuery('body').css('background', 'url(__STATIC__/themes/switch/images/pattern/'+name+'.png) repeat center center scroll');
				jQuery('body').css('background-size', 'auto');
	});
// Style Selector function ////////////////////////////////////
	jQuery('.style a').click(function(e) {
		e.preventDefault();
		jQuery(this).parent().find('img').removeClass('active');
		jQuery(this).find('img').addClass('active');

		var name = jQuery(this).attr('name');

		if(name == 'green') {
			jQuery('#callCss').attr('href', '');
		} else {
			jQuery('#callCss').attr('href', 'http://localhost:8080/mine/public/static/themes/'+name+'/bootstrap.min.css');
		}

	});
	
	/* Settings Button */
	$('#themesBtn').click(function() {
	  $('#secectionBox').animate({
		right:'0'
	  }, 500, function() {
		// Animation complete.
	  });
	  $('#themesBtn').animate({
		right:'-80'
	  }, 100, function() {
		// Animation complete.
	  });
	}); 


	$('#hideme').click(function() {
		$('#secectionBox').animate({
		right:'-999'
	  }, 500, function() {
		// Animation complete.
	  });
	  
	  $('#themesBtn').animate({
		right:'0'
	  }, 700, function() {
		// Animation complete.
	  }); 
	});

});
<?php echo '</script'; ?>
>
<span id="themesBtn"></span>
</body></html><?php
}
/* {block "style"} */
class Block_234485b1e898a009c07_72023171 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_234485b1e898a009c07_72023171',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "style"} */
/* {block "carouselBlk"} */
class Block_327535b1e898a0b29f5_76868745 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'carouselBlk' => 
  array (
    0 => 'Block_327535b1e898a0b29f5_76868745',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "carouselBlk"} */
/* {block "span9"} */
class Block_61025b1e898a189644_54379204 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'span9' => 
  array (
    0 => 'Block_61025b1e898a189644_54379204',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

	<?php
}
}
/* {/block "span9"} */
/* End inline template "C:\wamp64\www\mine\public\model.html" =============================*/
}
