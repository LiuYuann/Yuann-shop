<?php
/* Smarty version 3.1.32, created on 2018-06-10 17:09:03
  from 'C:\wamp64\www\mine\application\admin\view\member\Member-detail.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1ceaaf029994_91491471',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fcf2d63fbf344081591af04d4189c58d53f7707b' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\admin\\view\\member\\Member-detail.html',
      1 => 1528522188,
      2 => 'file',
    ),
    '5823787c55a2f03a73aa2d624b845693b45b0708' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\public\\adminmodel.html',
      1 => 1528621739,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:adminmodel.html' => 1,
  ),
),false)) {
function content_5b1ceaaf029994_91491471 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_311645b1ceaaedf6655_34437329', "data");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "adminmodel.html", '5823787c55a2f03a73aa2d624b845693b45b0708', 'content_5b1ceaaed750d5_57322227');
}
/* {block "data"} */
class Block_311645b1ceaaedf6655_34437329 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'data' => 
  array (
    0 => 'Block_311645b1ceaaedf6655_34437329',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div id="content">
		<div class="item">
		<div class="title">会员详细信息</div>
<div class="data-list clear">
	<table border="1">
		<tr><td>会员ID</td><td>会员昵称</td><td>邮箱</td><td>生日</td><td>电话号码</td><td>邮政编码</td><td>地址</td></tr>
		<tr>
		<td><?php echo $_smarty_tpl->tpl_vars['member']->value['mid'];?>
</td>
		<td><?php echo $_smarty_tpl->tpl_vars['member']->value['user'];?>
</td>
		<td><?php echo $_smarty_tpl->tpl_vars['member']->value['email'];?>
</td>
		<td><?php echo $_smarty_tpl->tpl_vars['member']->value['birthday'];?>
</td>
		<td><?php echo $_smarty_tpl->tpl_vars['member']->value['phone'];?>
</td>
		<td><?php echo $_smarty_tpl->tpl_vars['member']->value['postcode'];?>
</td>
		<td><?php echo $_smarty_tpl->tpl_vars['member']->value['address'];?>
</td>
		</tr>
	</table>
	<div class="title">会员购买记录</div>
	<br>
	<table border="1">
		<tr><td>商品ID</td><td>商品名</td><td>单价</td><td>数量</td><td>购买时间</td></tr>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['record']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
			<tr>
			<td><?php echo $_smarty_tpl->tpl_vars['row']->value['gid'];?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['row']->value['gname'];?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['row']->value['price'];?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['row']->value['num'];?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['row']->value['time'];?>
</td>
			</tr>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</table>
	<div class="pagination">
	<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

	<br class="clr"/>
</div>
</div>
	</div>
<?php
}
}
/* {/block "data"} */
/* Start inline template "C:\wamp64\www\mine\public\adminmodel.html" =============================*/
function content_5b1ceaaed750d5_57322227 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>后台管理系统</title>
	<link rel="shortcut icon" href="__STATIC__/themes/images/ico/favicon.ico">
	<link id="callCss" rel="stylesheet" href="__STATIC__/bootstrap/css/bootstrap.min.css" media="screen">
	<link href="__STATIC__/admin/css/admin.css" rel="stylesheet" />
	<?php echo '<script'; ?>
 src="__STATIC__/admin/js/jquery-3.3.1.js"><?php echo '</script'; ?>
>
</head>
<body>
<div id="top">
	<h1 class="left">后台管理系统</h1>
	<ul class="right">
		<li>欢迎您&nbsp;<?php echo session('admin_name');?>
</li>
		<li>|</li><li><a href="__ROOT__/index.php/index/index/index" target="_blank">前台首页</a></li>
		<li>|</li><li><a href="__ROOT__/index.php/admin/login/logout">退出登录</a></li>
	</ul>
</div>
<div id="main">
	<div id="menu" class="left">
		<ul><li><a href="__ROOT__/index.php/admin/index/index" id="Index_index">后台首页</a></li>
			<li><a href="__ROOT__/index.php/admin/addgoods/index" id="Goods_add">商品添加</a></li>
			<li><a href="__ROOT__/index.php/admin/showgoods/index?order=1" id="Goods_index">商品列表</a></li>
			<li><a href="__ROOT__/index.php/admin/category/index" id="Category_index">商品分类</a></li>
			<li><a href="__ROOT__/index.php/admin/member/index" id="Member_index">会员管理</a></li>
		</ul>
	</div>
	  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_168155b1ceaaedb8ef9_46626325', "data");
?>

	
</div>
</body>
</html><?php
}
/* {block "data"} */
class Block_168155b1ceaaedb8ef9_46626325 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'data' => 
  array (
    0 => 'Block_168155b1ceaaedb8ef9_46626325',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "data"} */
/* End inline template "C:\wamp64\www\mine\public\adminmodel.html" =============================*/
}
