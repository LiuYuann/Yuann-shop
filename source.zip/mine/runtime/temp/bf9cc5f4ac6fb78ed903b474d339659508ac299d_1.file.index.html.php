<?php
/* Smarty version 3.1.32, created on 2018-06-12 08:42:49
  from 'C:\wamp64\www\mine\application\admin\view\index\index.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1f1709a07840_10666830',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bf9cc5f4ac6fb78ed903b474d339659508ac299d' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\admin\\view\\index\\index.html',
      1 => 1528351923,
      2 => 'file',
    ),
    '5823787c55a2f03a73aa2d624b845693b45b0708' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\public\\adminmodel.html',
      1 => 1528621739,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:adminmodel.html' => 1,
  ),
),false)) {
function content_5b1f1709a07840_10666830 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8555b1f17099f47d3_04573653', "data");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "adminmodel.html", '5823787c55a2f03a73aa2d624b845693b45b0708', 'content_5b1f1709978244_51551974');
}
/* {block "data"} */
class Block_8555b1f17099f47d3_04573653 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'data' => 
  array (
    0 => 'Block_8555b1f17099f47d3_04573653',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div id="content">
		<div class="item">
			<div class="title">后台首页</div>
			<div class="data-list clear">欢迎进入后台！请从左侧选择一个操作。</div>
		</div>
</div>
<?php
}
}
/* {/block "data"} */
/* Start inline template "C:\wamp64\www\mine\public\adminmodel.html" =============================*/
function content_5b1f1709978244_51551974 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>后台管理系统</title>
	<link rel="shortcut icon" href="__STATIC__/themes/images/ico/favicon.ico">
	<link id="callCss" rel="stylesheet" href="__STATIC__/bootstrap/css/bootstrap.min.css" media="screen">
	<link href="__STATIC__/admin/css/admin.css" rel="stylesheet" />
	<?php echo '<script'; ?>
 src="__STATIC__/admin/js/jquery-3.3.1.js"><?php echo '</script'; ?>
>
</head>
<body>
<div id="top">
	<h1 class="left">后台管理系统</h1>
	<ul class="right">
		<li>欢迎您&nbsp;<?php echo session('admin_name');?>
</li>
		<li>|</li><li><a href="__ROOT__/index.php/index/index/index" target="_blank">前台首页</a></li>
		<li>|</li><li><a href="__ROOT__/index.php/admin/login/logout">退出登录</a></li>
	</ul>
</div>
<div id="main">
	<div id="menu" class="left">
		<ul><li><a href="__ROOT__/index.php/admin/index/index" id="Index_index">后台首页</a></li>
			<li><a href="__ROOT__/index.php/admin/addgoods/index" id="Goods_add">商品添加</a></li>
			<li><a href="__ROOT__/index.php/admin/showgoods/index?order=1" id="Goods_index">商品列表</a></li>
			<li><a href="__ROOT__/index.php/admin/category/index" id="Category_index">商品分类</a></li>
			<li><a href="__ROOT__/index.php/admin/member/index" id="Member_index">会员管理</a></li>
		</ul>
	</div>
	  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_217185b1f17099b78e6_58388333', "data");
?>

	
</div>
</body>
</html><?php
}
/* {block "data"} */
class Block_217185b1f17099b78e6_58388333 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'data' => 
  array (
    0 => 'Block_217185b1f17099b78e6_58388333',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "data"} */
/* End inline template "C:\wamp64\www\mine\public\adminmodel.html" =============================*/
}
