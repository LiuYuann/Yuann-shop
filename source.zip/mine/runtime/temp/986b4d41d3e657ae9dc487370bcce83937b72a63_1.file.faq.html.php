<?php
/* Smarty version 3.1.32, created on 2018-06-10 10:43:02
  from 'C:\wamp64\www\mine\application\index\view\faq\faq.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1c9036c21f93_53973016',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '986b4d41d3e657ae9dc487370bcce83937b72a63' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\index\\view\\faq\\faq.html',
      1 => 1527934649,
      2 => 'file',
    ),
    '6e1452b4c661213e182963508266af1b04b388d2' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\public\\model.html',
      1 => 1528597951,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:model.html' => 1,
  ),
),false)) {
function content_5b1c9036c21f93_53973016 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_121835b1c9036bdd242_89963098', "style");
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_300845b1c9036bff6b5_73956242', "span9");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "model.html", '6e1452b4c661213e182963508266af1b04b388d2', 'content_5b1c90369c46d7_37261903');
}
/* {block "style"} */
class Block_121835b1c9036bdd242_89963098 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_121835b1c9036bdd242_89963098',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript">
 window.onload = function(){ 
　　$('#sidebar').remove();  
} 	
<?php echo '</script'; ?>
>
<?php
}
}
/* {/block "style"} */
/* {block "span9"} */
class Block_300845b1c9036bff6b5_73956242 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'span9' => 
  array (
    0 => 'Block_300845b1c9036bff6b5_73956242',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1>常见问题</h1>
<hr class="soften"/>	
<div class="accordion" id="accordion2">
	<div class="accordion-group">
	  <div class="accordion-heading">
		<h4><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
		  商品描述不符、质量有问题该怎么办？
		</a></h4>
	  </div>
	  <div id="collapseOne" class="accordion-body collapse"  >
		<div class="accordion-inner">
			<div id="se-knowledge">
<p><strong>描述不符及质量问题</strong><span >，指买家收到的商品与卖家发布该商品信息时的描述、或是之前买卖双方的约定存在不符的情况，包含商品瑕疵、保质期、颜色、数量、邮费、发票、发货情况、交易附带物件等相关信息。</span></p>

<p>&nbsp;</p>

<p><span>①如果<strong>交易还在进行中，</strong><span>请您及时联系卖家协商</span></span><span>>换货</a>或退货</a>。</span></p>

<p><span><strong>若因邮费或退货退款等问题无法协商一致，您可以申请退款，在卖家拒绝申请后及时申请“</strong></span><span>要求客服介入</span></a><span><strong>”</strong><span>，并上传有效凭证（如实物对比图片、质量检测凭证等），待淘宝客服核实。</span></span></p>

<p>&nbsp;</p>

<p><span>②如果<strong>交易成功的0-15天内，</strong>请您使用阿里旺旺联系卖家协商换货或退货，保存协商好的阿里旺旺聊天记录和退货凭证；如果在交易成功后的15天内未得到解决（如退款还未收到），请您及时进入“我的”—“</span><span>已买到的宝贝</span></a><span>”页面找到对应的交易，点击“</span><span>申请售后</span></a><span>”，并上传相关凭证（如实物对比图片、聊天记录截图，退货物流底单，质量检测凭证等），等待客服介入核实处理。</span></p>

<p>&nbsp;</p>

<p><span><span><strong>提醒：</strong></span>售后维权<strong>机会只有一次</strong>，建议等卖家处理好售后后再撤销维权。维权时间是交易成功后<strong>0-15天</strong>，请您注意维权时间，逾期未发起，淘宝网将不再受理。</span></p>
<p><span>&nbsp;</span></p>



<p>&nbsp;</p>
</div>

		</div>
	  </div>
	</div>
	<div class="accordion-group">
	  <div class="accordion-heading">
		<h4><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
		 如何设置/新增/删除收货地址？
		</a></h4>
	  </div>
	  <div id="collapseTwo" class="accordion-body collapse"  >
		<div class="accordion-inner">
		  <div id="se-knowledge"><link href="//g.alicdn.com/crm/kbskin/css/plugins/ckeditor/pc.css" rel="stylesheet">
<h5 ><span>亲，您可以进入 【我的账户】<span>— 【</span></span><span><span><span>我的</span></span><span><span>收货地址</span></span></a>】&nbsp;</span><span>页面里设置收货地址，最多可以保存<span>20</span>个哦~</span></h4><h4>&nbsp;</h5><h5 data-spm-anchor-id="a21pu.8253649.0.i2.108e78d5lQg8Jy">若已经下单了，只有卖家才可以修改收货地址哦~请在【我的账户】-【已买到的宝贝</a>】，找到您需要修改地址的订单，<span>点击【和我联系】，</span>通过跟卖家协商进行修改地址。</h5><h5>&nbsp;</h5>
</div>
		</div>
	  </div>
	</div>
	<div class="accordion-group">
	  <div class="accordion-heading">
		<h4><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
		  如何取消订单？
		</a></h4>
	  </div>
	  <div id="collapseThree" class="accordion-body collapse"  >
		<div class="accordion-inner">
		  <div class="info-box">
        <div id="se-knowledge">
<p >&nbsp;</p><p><strong>若您想手动取消订单：</strong></p><p >非货到付款交易，拍下宝贝后，如果您还没有进行支付宝付款，但需要取消交易订单，或货到付款交易，在您拍下后，卖家发货前，您都可以取消交易，可以点击 <strong>【取消订单】</strong> 的按钮关闭交易订单</p><p >具体操作的步骤如下：</p><p>点击后再选择取消订单的原因：</p><<p>取消后页面即变成如下页面：</p><p><strong>若您不想手动取消订单：</strong></p><ol >
	<li>
	<p>未付款的商品在商品拍下后的3天内如果交易未付款系统会自动关闭的哦；</p>
	</li>
	<li>
	<p>已付款但是卖家未发货的订单，您可以先申请退款，并且旺旺与卖家联系反馈，申请退款成功后订单会自动关闭。如何申请退款。</p>
	</li>
</ol><p><strong>*</strong><strong>温馨提示：</strong></p><p>话费订单没有取消订单的入口，需要您等待3天系统交易自动关闭哦。</p><p>买家每天关闭交易的操作次数只有<strong>5</strong><strong>次</strong>，操作 <strong>满5次 </strong>后就只能由卖家操作关闭了，且即使您只需要取消订单中的其中一件宝贝，还是需要由卖家哦</p><p data-spm-anchor-id="a21pu.8253649.0.i10.108e78d5lQg8Jy">只有在 <strong>等待买家付款 </strong>的状态下才能关闭交易，如果需要取消订单，但双方都没有操作关闭，交易会在3天付款期结束后因买家未付款系统超时自动关闭。交易取消后 <strong>对买卖双方的账户信用没有影响</strong><strong> </strong>，但购买记录会存在。</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
</div>
    </div>
		</div>
	  </div>
	</div>
	
	<div class="accordion-group">
	  <div class="accordion-heading">
		<h4><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFour">
		  常用快递公司联系方式有哪些？
		</a></h4>
	  </div>
	  <div id="collapseFour" class="accordion-body collapse"  >
		<div class="accordion-inner">
		  <div id="se-knowledge" >
<p><span>常用快递公司的官方电话联系方式如下：</span></p><p><a href="http://www.zto.cn/" target="_blank">中通速递</a>：<a href="tel:95311" target="_blank">95311</a></p><p><a href="http://www.sto.cn/" target="_blank">申通快递</a>：<a href="tel:95543" target="_blank">95543</a></p><p><a href="http://www.yto.net.cn" target="_blank">圆通快递</a>：<a href="tel:95554" target="_blank">95554</a></p><p><a href="http://www.htky365.com/" target="_blank">汇通快递</a>：<a href="tel:400-956-5656" target="_blank">400-956-5656</a></p><p><a href="http://www.yundaex.com/" target="_blank">韵达快递</a>：<a href="tel:95546" target="_blank">95546</a></p><p><a href="http://www.ttkdex.com/" target="_blank">天天快递</a>：<a href="tel:400-188-8888" target="_blank">400-188-8888</a></p><p><a href="http://www.zjs.com.cn/" target="_blank">宅急送</a>：<a href="tel:400-678-9000" target="_blank">400-678-9000</a></p><p><a href="http://www.sf-express.com" target="_blank">顺丰速运</a>：<a href="tel:95338" target="_blank">95338</a></p><p><a href="http://www.ems.com.cn/" target="_blank">EMS 邮政特快</a>：<a href="tel：11183" target="_blank">11183</a></p><p><a href="http://www.qfkd.com.cn/" target="_blank">全峰快递</a>：<a href="tel:400-100-0001" target="_blank">400-100-0001</a></p><p><a href="http://www.deppon.com/" target="_blank">德邦快递</a>：<a href="tel:95353" target="_blank">95353</a></p><p><a href="https://www.rrswl.com/" target="_blank">日日顺：</a><a href="tel:400-999-9999" target="_blank">400-999-9999</a></p><p><a href="http://www.gto365.com/" target="_blank">国通快递</a>：<a href="tel:400-111-1123" target="_blank">400-111-1123</a></p><p><a href="http://www.uc56.com/" target="_blank">优速快递</a>：<a href="tel：400-111-119" target="_blank">400-111-1119</a></p><p><a href="http://www.kjkd.com/" target="_blank">快捷速递</a>：<a href="tel:400-833-3666" target="_blank">400-833-3666</a></p>
</div>
		</div>
	  </div>
	</div>
	
	<div class="accordion-group">
	  <div class="accordion-heading">
		<h4><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseFive">
		 忘记账号密码，怎么找回？
		</a></h4>
	  </div>
	  <div id="collapseFive" class="accordion-body collapse"  >
		<div class="accordion-inner">
		 <div id="se-knowledge">
<p ><span >根据页面提示验证身份后重置您的账号密码</span></span></span>哦<span>~&nbsp;</span></span></p><p class="MsoNormal" d>如果您操作找回密码时无法通过身份验证，您可以<span>打开</span><strong>手机APP</strong><span >，在首页点击左上角扫一扫功能扫描以下二维码，根据页面提示通过信息核实的自助操作修改账号绑定手机。</span>手机修改成功后，再使用手机验证修改您的账户密码哦~</p></div>
	  </div>
	</div>
	</div>
	
	<div class="accordion-group">
	  <div class="accordion-heading">
		<h4><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseSix">
		  货物被他人签收，怎么办？
		</a></h4>
	  </div>
	  <div id="collapseSix" class="accordion-body collapse"  >
		<div class="accordion-inner">
		  <div ><p >亲，货物显示被他人签收，请联系卖家和物流公司确认货物所在处，及时签收货物。若您的包裹被物业、前台等代签，您可尽快联系取回，防止包裹遗失。如果您的商品一直没有收到，可以及时申请退款。<br>
*温馨提示：<br>
1. 卖家发货后您有10天（快递10天，平邮30天）时间确认是否收到货物，请注意超时时间，及时申请退款，以免系统自动打款卖家。<br>
2.&nbsp;在该笔订单的物流详情显示签收后，订单交易成功前，您可以在手机淘宝/PC淘宝网页上找到该笔订单，在物流详情页点击“物流投诉”，选择相应原因发起投诉（原因包括：未收到货且未告知货在哪、未经允许包裹放入代收点、未经允许包裹放入自提柜）。物流公司一般会在48小时内电话回访您进行处理，请您耐心等待。</p>

<p >注：已开通投诉入口的快递公司：百世快递，德邦快递，国通快递，快捷快递，全峰快递，申通快递，顺丰速运，天天快递，优速快递，圆通速递，韵达快递，宅急送，中通快递</p>
</div>
		</div>
	  </div>
	</div>
  </div>
<?php
}
}
/* {/block "span9"} */
/* Start inline template "C:\wamp64\www\mine\public\model.html" =============================*/
function content_5b1c90369c46d7_37261903 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<html lang="en"><head>
    <meta charset="utf-8">
    <title>Yuann shop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">	
<!-- Bootstrap style --> 
    <link id="callCss" rel="stylesheet" href="__STATIC__/themes/bootshop/bootstrap.min.css" media="screen">
    <link href="__STATIC__/themes/css/base.css" rel="stylesheet" media="screen">
<!-- Bootstrap style responsive -->	
	<link href="__STATIC__/themes/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="__STATIC__/themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->	
	<link href="__STATIC__/themes/js/google-code-prettify/prettify.css" rel="stylesheet">
<!-- fav and touch icons -->
    <link rel="shortcut icon" href="__STATIC__/themes/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="__STATIC__/themes/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="__STATIC__/themes/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="__STATIC__/themes/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="__STATIC__/themes/images/ico/apple-touch-icon-57-precomposed.png">
	<style type="text/css" id="enject"></style>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery-3.3.1.js" type="text/javascript"><?php echo '</script'; ?>
>
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_296565b1c90369e7f26_26556026', "style");
?>

  </head>
<body>
<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
	<div class="span6">
	欢迎<strong> <?php echo session('user');?>
</strong>
	<a href="__ROOT__/index.php/index/login/logout"><span class="btn btn-mini btn-primary">退出登录  </span> </a> 
	</div>
	<div class="span6">
	<div class="pull-right cart-data">
		<a href="__ROOT__/index.php/index/record"><span class="btn btn-mini "><i class="icon-shopping-cart icon-white"></i> 购买记录  </span></a>
		<span class="btn btn-mini sum">￥<?php echo session('sum');?>
</span>
		<a href="__ROOT__/index.php/index/login"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> 购物车  </span> </a> 
	</div>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" href="__ROOT__/index.php/index/"><img src="__STATIC__/themes/images/logo.png" alt="Bootsshop"></a>
		<form class="form-inline navbar-search" method="get" action="__ROOT__/index.php/index/products">
		<input id="srchFld" class="srchTxt" name='key' type="text" style="width:200px;height:30px">
		  <select class="srchTxt" name='factor'>
			<option value='所有'>所有</option>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, session('kinds'), 'value', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
			<option value='<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
'><?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</option>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            
		</select> 
		  <button type="submit" id="submitButton" name='search' class="btn btn-primary">搜索</button>
    </form>
    <ul id="topMenu" class="nav pull-right">
	 <li class=""><a href="__ROOT__/index.php/index/specialoffer">特价优惠</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/transfer">物流详情</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/contact">联系我</a></li>
	 <li class="">
	 <a href="__ROOT__/index.php/index/login" role="button"  style="padding-right:0"><span class="btn btn-large btn-success">登录</span></a>
	</li>
    </ul>
  </div>
</div>
</div>
</div>
<!-- Header End====================================================================== -->

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_212975b1c9036aa2737_89859862', "carouselBlk");
?>


<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<div id="sidebar" class="span3">
		<div class="well well-small cart-data"><a id="myCart"  href="__ROOT__/index.php/index/login"><img src="__STATIC__/themes/images/ico-cart.png" alt="cart"><span class='count'><?php echo session('count');?>
件商品</span>  <span class="badge badge-warning pull-right sum"><span class='sum'>￥<?php echo session('sum');?>
</span></span></a></div>
		<br>
		<ul id="sideManu" class="nav nav-tabs nav-stacked">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, session('kinds'), 'value', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
			<li class="subMenu open"><a> <?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</a>
				<ul>
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['value']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
						<li><a href="__ROOT__/index.php/index/products?cid=<?php echo $_smarty_tpl->tpl_vars['row']->value['cid'];?>
"><i class="icon-chevron-right"></i><?php echo $_smarty_tpl->tpl_vars['row']->value['cname'];?>
</a></li>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</ul>
			</li>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ul>
		<br>
		<br>
			<div class="thumbnail">
			<h4 style='text-align:center; color:red;'>销量冠军</h4>
				<img src="__STATIC__/imgs/computer/peripherals/45140873352/1.jpg" title="Bootshop New Kindel" alt="Bootshop Kindel">
				<div class="caption">
				  <h5>陈子豪外设店宜博M639电竞机械鼠标电脑有线吃鸡游戏宏绝地求生</h5>
				    <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail/index?gid=45140873352"> <i class="icon-zoom-in"></i></a> <a class="btn" href="productdetail?gid=45140873352">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="productdetail?gid=45140873352">￥107</a></h4>
				</div>
			  </div><br><br>
			<div class="thumbnail">
				<img src="__STATIC__/themes/images/payment_methods.png" title="Bootshop 支付方式" alt="Payments Methods">
				<div class="caption">
				  <h5>支付方式</h5>
				</div>
			  </div>
	</div>
<!-- Sidebar end=============================================== -->
		
		
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_25825b1c9036b89857_10188145', "span9");
?>

		
		</div>
	</div>
</div>
<!-- Footer ================================================================== -->
	<div id="footerSection">
	<div class="container">
		<div class="row">
			<div class="span3">
				<h4>账户</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/login">你的账户</a>
				<a href="__ROOT__/index.php/index/login">个人信息</a> 
				<a href="__ROOT__/index.php/index/login">收货地址</a> 
				<a href="__ROOT__/index.php/index/specialoffer">折扣信息</a>  
				<a href="__ROOT__/index.php/index/record">购买记录</a>
			 </div>
			<div class="span3">
				<h4>信息</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/contact">联系我们</a>  
				<a href="__ROOT__/index.php/index/register">注册</a>  
				<a href="__ROOT__/index.php/index/legalnotice">法律信息</a>  
				<a href="__ROOT__/index.php/index/tac">条款和条件</a> 
				<a href="__ROOT__/index.php/index/faq">常问问题</a>
			 </div>
			<div class="span3">
				<h4>优惠</h4>
				<br><br>
				<a href="#">新款商品</a> 
				<a href="#">畅销品</a>  
				<a href="__ROOT__/index.php/index/specialoffer">特别优惠</a>  
				<a href="#">生产商</a> 
				<a href="#">供应商</a> 
			 </div>
			<div id="socialMedia" class="span3 pull-right">
				<h4>社交媒体 </h4>
			<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;'>
		<img class='1' style='display:none;position:absolute;top:-30px;' width="100" height="100" src="__STATIC__/themes/images/qqma.jpg"/>
	</div>
&nbsp;&nbsp;<img class='2' width="60"  height="60" src="__STATIC__/themes/images/qq.png" title="QQ" alt="QQ"/>
</div>
<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;' >
		<img width="100" height="100" class='3' style='display:none;position:absolute;top:-30px;' src="__STATIC__/themes/images/weixinma.png"/>
	</div>

&nbsp;&nbsp;<img width="60" class='4' height="60" src="__STATIC__/themes/images/weixin.png" title="微信" alt="微信"/>
</div>
<div style='float:left;'>
&nbsp;&nbsp;&nbsp;<br><br><br><br><br><a href="https://weibo.com/u/5703804590"><img width="60" height="60" src="__STATIC__/themes/images/weibo.png" title="微博" alt="微博"/></a> 
</div>

                <?php echo '<script'; ?>
>  
                $(document).ready(function(){  
                    $(".2").mouseover(function(){
                    $(".1").show();}); 
                    $(".2").mouseout(function(){$(".1").hide();});
                    $(".4").mouseover(function(){$(".3").show();});  
                    $(".4").mouseout(function(){$(".3").hide();});
                });   
                <?php echo '</script'; ?>
>  
		 </div>
         
	</div><!-- Container End -->
	</div>
</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/google-code-prettify/prettify.js"><?php echo '</script'; ?>
>
	
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/bootshop.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery.lightbox-0.5.js"><?php echo '</script'; ?>
>
	
	<!-- Themes switcher section ============================================================================================= -->
<div id="secectionBox">
<link rel="stylesheet" href="__STATIC__/themes/switch/themeswitch.css" type="text/css" media="screen">
<?php echo '<script'; ?>
 src="__STATIC__/themes/switch/theamswitcher.js" type="text/javascript" charset="utf-8"><?php echo '</script'; ?>
>
	<div id="themeContainer">
	<div id="hideme" class="themeTitle">主题更改</div>
	<div class="themeName">默认 主题</div>
	<div class="images style">
	<a href="__STATIC__/themes/css/#" name="bootshop"><img src="__STATIC__/themes/switch/images/clr/bootshop.png" alt="bootstrap business templates" class="active"></a>
	<a href="__STATIC__/themes/css/#" name="businessltd"><img src="__STATIC__/themes/switch/images/clr/businessltd.png" alt="bootstrap business templates" class=""></a>
	</div>
	<div class="themeName">皮肤</div>
	<div class="images style">
		<a href="__STATIC__/themes/css/#" name="amelia" title="Amelia"><img src="__STATIC__/themes/switch/images/clr/amelia.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="spruce" title="Spruce"><img src="__STATIC__/themes/switch/images/clr/spruce.png" alt="bootstrap business templates" class=""></a>
		<a href="__STATIC__/themes/css/#" name="superhero" title="Superhero"><img src="__STATIC__/themes/switch/images/clr/superhero.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cyborg"><img src="__STATIC__/themes/switch/images/clr/cyborg.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cerulean"><img src="__STATIC__/themes/switch/images/clr/cerulean.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="journal"><img src="__STATIC__/themes/switch/images/clr/journal.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="readable"><img src="__STATIC__/themes/switch/images/clr/readable.png" alt="bootstrap business templates"></a>	
		<a href="__STATIC__/themes/css/#" name="simplex"><img src="__STATIC__/themes/switch/images/clr/simplex.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="slate"><img src="__STATIC__/themes/switch/images/clr/slate.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="spacelab"><img src="__STATIC__/themes/switch/images/clr/spacelab.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="united"><img src="__STATIC__/themes/switch/images/clr/united.png" alt="bootstrap business templates"></a>
		<p style="margin:0;line-height:normal;margin-left:-10px;display:none;"><small>These are just examples and you can build your own color scheme in the backend.</small></p>
	</div>
	<div class="themeName">背景颜色 </div>
	<div class="images patterns">
		<a href="__STATIC__/themes/css/#" name="pattern1"><img src="__STATIC__/themes/switch/images/pattern/pattern1.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="pattern2"><img src="__STATIC__/themes/switch/images/pattern/pattern2.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern3"><img src="__STATIC__/themes/switch/images/pattern/pattern3.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern4"><img src="__STATIC__/themes/switch/images/pattern/pattern4.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern5"><img src="__STATIC__/themes/switch/images/pattern/pattern5.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern6"><img src="__STATIC__/themes/switch/images/pattern/pattern6.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern7"><img src="__STATIC__/themes/switch/images/pattern/pattern7.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern8"><img src="__STATIC__/themes/switch/images/pattern/pattern8.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern9"><img src="__STATIC__/themes/switch/images/pattern/pattern9.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern10"><img src="__STATIC__/themes/switch/images/pattern/pattern10.png" alt="bootstrap business templates"></a>
		
		<a href="__STATIC__/themes/css/#" name="pattern11"><img src="__STATIC__/themes/switch/images/pattern/pattern11.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern12"><img src="__STATIC__/themes/switch/images/pattern/pattern12.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern13"><img src="__STATIC__/themes/switch/images/pattern/pattern13.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern14"><img src="__STATIC__/themes/switch/images/pattern/pattern14.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern15"><img src="__STATIC__/themes/switch/images/pattern/pattern15.png" alt="bootstrap business templates"></a>
		
		<a href="__STATIC__/themes/css/#" name="pattern16"><img src="__STATIC__/themes/switch/images/pattern/pattern16.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern17"><img src="__STATIC__/themes/switch/images/pattern/pattern17.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern18"><img src="__STATIC__/themes/switch/images/pattern/pattern18.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern19"><img src="__STATIC__/themes/switch/images/pattern/pattern19.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern20"><img src="__STATIC__/themes/switch/images/pattern/pattern20.png" alt="bootstrap business templates"></a>
		 
	</div>
	</div>	
</div>
<span id="themesBtn"></span>
</body></html><?php
}
/* {block "style"} */
class Block_296565b1c90369e7f26_26556026 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_296565b1c90369e7f26_26556026',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "style"} */
/* {block "carouselBlk"} */
class Block_212975b1c9036aa2737_89859862 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'carouselBlk' => 
  array (
    0 => 'Block_212975b1c9036aa2737_89859862',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "carouselBlk"} */
/* {block "span9"} */
class Block_25825b1c9036b89857_10188145 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'span9' => 
  array (
    0 => 'Block_25825b1c9036b89857_10188145',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

	<?php
}
}
/* {/block "span9"} */
/* End inline template "C:\wamp64\www\mine\public\model.html" =============================*/
}
