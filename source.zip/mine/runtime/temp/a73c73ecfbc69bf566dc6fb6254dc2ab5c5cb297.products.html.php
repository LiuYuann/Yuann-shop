<?php
/* Smarty version 3.1.32, created on 2018-06-11 22:33:16
  from 'C:\wamp64\www\mine\application\index\view\products\products.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b1e882cbb8926_10424251',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '84b83bea19042622b96961b9b5fbd532310128f9' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\index\\view\\products\\products.html',
      1 => 1528545697,
      2 => 'file',
    ),
    '6e1452b4c661213e182963508266af1b04b388d2' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\public\\model.html',
      1 => 1528727486,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5b1e882cbb8926_10424251 (Smarty_Internal_Template $_smarty_tpl) {
?><html lang="en"><head>
    <meta charset="utf-8">
    <title>Yuann shop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">	
<!-- Bootstrap style --> 
    <link id="callCss" rel="stylesheet" href="__STATIC__/themes/bootshop/bootstrap.min.css" media="screen">
    <link href="__STATIC__/themes/css/base.css" rel="stylesheet" media="screen">
<!-- Bootstrap style responsive -->	
	<link href="__STATIC__/themes/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="__STATIC__/themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->	
	<link href="__STATIC__/themes/js/google-code-prettify/prettify.css" rel="stylesheet">
<!-- fav and touch icons -->
    <link rel="shortcut icon" href="__STATIC__/themes/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="__STATIC__/themes/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="__STATIC__/themes/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="__STATIC__/themes/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="__STATIC__/themes/images/ico/apple-touch-icon-57-precomposed.png">
	<style type="text/css" id="enject"></style>
	<script src="__STATIC__/themes/js/jquery-3.3.1.js" type="text/javascript"></script>
  
	

  </head>
<body>
<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
	<div class="span6">
	欢迎<strong> 请登陆</strong>
	<a href="__ROOT__/index.php/index/login/logout"><span class="btn btn-mini btn-primary">退出登录  </span> </a> 
	</div>
	<div class="span6">
	<div class="pull-right cart-data">
		<a href="__ROOT__/index.php/index/record"><span class="btn btn-mini "><i class="icon-shopping-cart icon-white"></i> 购买记录  </span></a>
		<span class="btn btn-mini sum">￥0</span>
		<a href="__ROOT__/index.php/index/login"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> 购物车  </span> </a> 
	</div>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" href="__ROOT__/index.php/index/"><img src="__STATIC__/themes/images/logo.png" alt="Bootsshop"></a>
		<form class="form-inline navbar-search" method="get" action="__ROOT__/index.php/index/products">
		<input id="srchFld" class="srchTxt" name='key' type="text" style="width:200px;height:30px">
		  <select class="srchTxt" name='factor'>
			<option value='所有'>所有</option>
						<option value='电脑/办公'>电脑/办公</option>
				<option value='手机'>手机</option>
				<option value='摄影摄像'>摄影摄像</option>
				<option value='影音娱乐'>影音娱乐</option>
				<option value='智能设备'>智能设备</option>
	            
		</select> 
		  <button type="submit" id="submitButton" name='search' class="btn btn-primary">搜索</button>
    </form>
    <ul id="topMenu" class="nav pull-right">
	 <li class=""><a href="__ROOT__/index.php/index/specialoffer">特价优惠</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/transfer">物流详情</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/contact">联系我</a></li>
	 <li class="">
	 <a href="__ROOT__/index.php/index/login" role="button"  style="padding-right:0"><span class="btn btn-large btn-success">登录</span></a>
	</li>
    </ul>
  </div>
</div>
</div>
</div>
<!-- Header End====================================================================== -->


	


<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<div id="sidebar" class="span3">
		<div class="well well-small cart-data"><a id="myCart"  href="__ROOT__/index.php/index/login"><img src="__STATIC__/themes/images/ico-cart.png" alt="cart"><span class='count'>0件商品</span>  <span class="badge badge-warning pull-right sum"><span class='sum'>￥0</span></span></a></div>
		<br>
		<ul id="sideManu" class="nav nav-tabs nav-stacked">
					<li class="subMenu open"><a> 电脑/办公</a>
				<ul>
											<li><a href="__ROOT__/index.php/index/products?cid=1"><i class="icon-chevron-right"></i>电脑整机</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=2"><i class="icon-chevron-right"></i>电脑配件</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=3"><i class="icon-chevron-right"></i>电脑外设</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=4"><i class="icon-chevron-right"></i>办公设备</a></li>
									</ul>
			</li>
				<li class="subMenu open"><a> 手机</a>
				<ul>
											<li><a href="__ROOT__/index.php/index/products?cid=5"><i class="icon-chevron-right"></i>手机</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=6"><i class="icon-chevron-right"></i>手机配件</a></li>
									</ul>
			</li>
				<li class="subMenu open"><a> 摄影摄像</a>
				<ul>
											<li><a href="__ROOT__/index.php/index/products?cid=7"><i class="icon-chevron-right"></i>单反</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=8"><i class="icon-chevron-right"></i>微单</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=9"><i class="icon-chevron-right"></i>摄像机</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=10"><i class="icon-chevron-right"></i>数码相机</a></li>
									</ul>
			</li>
				<li class="subMenu open"><a> 影音娱乐</a>
				<ul>
											<li><a href="__ROOT__/index.php/index/products?cid=11"><i class="icon-chevron-right"></i>耳机，耳麦</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=12"><i class="icon-chevron-right"></i>音箱音响</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=13"><i class="icon-chevron-right"></i>麦克风</a></li>
									</ul>
			</li>
				<li class="subMenu open"><a> 智能设备</a>
				<ul>
											<li><a href="__ROOT__/index.php/index/products?cid=14"><i class="icon-chevron-right"></i>智能手环</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=15"><i class="icon-chevron-right"></i>智能眼镜</a></li>
											<li><a href="__ROOT__/index.php/index/products?cid=16"><i class="icon-chevron-right"></i>智能机器人</a></li>
									</ul>
			</li>
			</ul>
		<br>
		<br>
			<div class="thumbnail">
			<h4 style='text-align:center; color:red;'>销量冠军</h4>
				<img src="__STATIC__/imgs/computer/peripherals/45140873352/1.jpg" title="Bootshop New Kindel" alt="Bootshop Kindel">
				<div class="caption">
				  <h5>陈子豪外设店宜博M639电竞机械鼠标电脑有线吃鸡游戏宏绝地求生</h5>
				    <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail/index?gid=45140873352"> <i class="icon-zoom-in"></i></a> <a class="btn" href="productdetail?gid=45140873352">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="productdetail?gid=45140873352">￥107</a></h4>
				</div>
			  </div><br><br>
			<div class="thumbnail">
				<img src="__STATIC__/themes/images/payment_methods.png" title="Bootshop 支付方式" alt="Payments Methods">
				<div class="caption">
				  <h5>支付方式</h5>
				</div>
			  </div>
	</div>
<!-- Sidebar end=============================================== -->
		
		
	
		
<div class="span9">
    <ul class="breadcrumb">
		<li><a href="__ROOT__/index.php/index/">主页</a> <span class="divider">/</span></li>
		<li class="active">商品</li>
    </ul>
	<h3> 商品 <small class="pull-right"> 600+ 现货商品 </small></h3>	
	<hr class="soft"/>
	<form class="form-horizontal span6">
		<div class="control-group">
		  <label class="control-label alignL">排序 </label>
			<select onchange="check(this.value);">
              <option>新品</option>
              <option>价格升序</option>
              <option>价格降序</option>
              <option>销量由高到低</option>
            </select>
		</div>
	  </form>
<br class="clr"/>
<div class="tab-content">
	<div class="tab-pane  active" id="blockView">
		<ul class="thumbnails">
					<li class="span3">
			  <div class="thumbnail">
				<a href="__ROOT__/index.php/index/productdetail?gid=564383637562"><img src="__STATIC__/imgs/phone/accessories/564383637562/1.jpg" alt="" style='height:260px;width:260px'/></a>
				<div class="caption">
				  <a href="__ROOT__/index.php/index/productdetail?gid=564383637562">手机指扣环金属超薄创意个性配件手环扣指环扣戒指支架磁吸圆形黑</a>
				  <p> 
					销量：85
				  </p>
				  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail?gid=564383637562"> <i class="icon-zoom-in"></i></a> <a class="btn" href="__ROOT__/index.php/index/productdetail?gid=564383637562">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">￥10</a></h4>
				</div>
			  </div>
			</li>
					<li class="span3">
			  <div class="thumbnail">
				<a href="__ROOT__/index.php/index/productdetail?gid=556481871428"><img src="__STATIC__/imgs/phone/accessories/556481871428/1.jpg" alt="" style='height:260px;width:260px'/></a>
				<div class="caption">
				  <a href="__ROOT__/index.php/index/productdetail?gid=556481871428">手机指扣环金属超薄创意个性配件手环扣指环扣戒指支架磁吸陀螺黑</a>
				  <p> 
					销量：81
				  </p>
				  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail?gid=556481871428"> <i class="icon-zoom-in"></i></a> <a class="btn" href="__ROOT__/index.php/index/productdetail?gid=556481871428">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">￥26</a></h4>
				</div>
			  </div>
			</li>
					<li class="span3">
			  <div class="thumbnail">
				<a href="__ROOT__/index.php/index/productdetail?gid=565159337963"><img src="__STATIC__/imgs/phone/accessories/565159337963/1.jpg" alt="" style='height:260px;width:260px'/></a>
				<div class="caption">
				  <a href="__ROOT__/index.php/index/productdetail?gid=565159337963">挂钩配件指环实用扣子新款贴手机防摔扣环手指套环车载小支架</a>
				  <p> 
					销量：87
				  </p>
				  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail?gid=565159337963"> <i class="icon-zoom-in"></i></a> <a class="btn" href="__ROOT__/index.php/index/productdetail?gid=565159337963">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">￥5</a></h4>
				</div>
			  </div>
			</li>
					<li class="span3">
			  <div class="thumbnail">
				<a href="__ROOT__/index.php/index/productdetail?gid=569760054866"><img src="__STATIC__/imgs/phone/accessories/569760054866/1.jpg" alt="" style='height:260px;width:260px'/></a>
				<div class="caption">
				  <a href="__ROOT__/index.php/index/productdetail?gid=569760054866">安卓苹果通用手机红外线发射器iphone6配件vivo万能空调遥控器头</a>
				  <p> 
					销量：56
				  </p>
				  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail?gid=569760054866"> <i class="icon-zoom-in"></i></a> <a class="btn" href="__ROOT__/index.php/index/productdetail?gid=569760054866">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">￥23</a></h4>
				</div>
			  </div>
			</li>
					<li class="span3">
			  <div class="thumbnail">
				<a href="__ROOT__/index.php/index/productdetail?gid=546091771164"><img src="__STATIC__/imgs/phone/accessories/546091771164/1.jpg" alt="" style='height:260px;width:260px'/></a>
				<div class="caption">
				  <a href="__ROOT__/index.php/index/productdetail?gid=546091771164">水滴手机指环支架华为手环支架苹果金属指环扣粘贴式通用创意配件</a>
				  <p> 
					销量：40
				  </p>
				  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail?gid=546091771164"> <i class="icon-zoom-in"></i></a> <a class="btn" href="__ROOT__/index.php/index/productdetail?gid=546091771164">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">￥19</a></h4>
				</div>
			  </div>
			</li>
					<li class="span3">
			  <div class="thumbnail">
				<a href="__ROOT__/index.php/index/productdetail?gid=544529964522"><img src="__STATIC__/imgs/phone/accessories/544529964522/1.jpg" alt="" style='height:260px;width:260px'/></a>
				<div class="caption">
				  <a href="__ROOT__/index.php/index/productdetail?gid=544529964522">手机扣指环扣支架支撑架金属手环通用指扣环配件支驾指架环环指女</a>
				  <p> 
					销量：25
				  </p>
				  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail?gid=544529964522"> <i class="icon-zoom-in"></i></a> <a class="btn" href="__ROOT__/index.php/index/productdetail?gid=544529964522">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">￥16</a></h4>
				</div>
			  </div>
			</li>
					<li class="span3">
			  <div class="thumbnail">
				<a href="__ROOT__/index.php/index/productdetail?gid=543620605527"><img src="__STATIC__/imgs/phone/accessories/543620605527/1.jpg" alt="" style='height:260px;width:260px'/></a>
				<div class="caption">
				  <a href="__ROOT__/index.php/index/productdetail?gid=543620605527">安卓TypeC手机防尘塞Mate10电源塞USB充电口R15金属Note8</a>
				  <p> 
					销量：38
				  </p>
				  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail?gid=543620605527"> <i class="icon-zoom-in"></i></a> <a class="btn" href="__ROOT__/index.php/index/productdetail?gid=543620605527">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">￥12</a></h4>
				</div>
			  </div>
			</li>
					<li class="span3">
			  <div class="thumbnail">
				<a href="__ROOT__/index.php/index/productdetail?gid=565075102482"><img src="__STATIC__/imgs/phone/accessories/565075102482/1.jpg" alt="" style='height:260px;width:260px'/></a>
				<div class="caption">
				  <a href="__ROOT__/index.php/index/productdetail?gid=565075102482">手机扣指环扣支架支撑架金属手环通用指扣环配件支驾指架环环指女</a>
				  <p> 
					销量：96
				  </p>
				  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail?gid=565075102482"> <i class="icon-zoom-in"></i></a> <a class="btn" href="__ROOT__/index.php/index/productdetail?gid=565075102482">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">￥11</a></h4>
				</div>
			  </div>
			</li>
					<li class="span3">
			  <div class="thumbnail">
				<a href="__ROOT__/index.php/index/productdetail?gid=557467580687"><img src="__STATIC__/imgs/phone/accessories/557467580687/1.jpg" alt="" style='height:260px;width:260px'/></a>
				<div class="caption">
				  <a href="__ROOT__/index.php/index/productdetail?gid=557467580687">床上用手机支架直播神器懒人看电视床头手机架通用夹配件支撑架子</a>
				  <p> 
					销量：84
				  </p>
				  <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail?gid=557467580687"> <i class="icon-zoom-in"></i></a> <a class="btn" href="__ROOT__/index.php/index/productdetail?gid=557467580687">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">￥28</a></h4>
				</div>
			  </div>
			</li>
				  </ul>
	<hr class="soft"/>
	</div>
</div>

<div class="pagination" style="text-align:center;">
	<ul class="pagination"><li class="disabled"><span>&laquo;</span></li> <li class="active"><span>1</span></li><li><a href="/mine/public/index.php/index/products?cid=6&amp;page=2">2</a></li><li><a href="/mine/public/index.php/index/products?cid=6&amp;page=3">3</a></li><li><a href="/mine/public/index.php/index/products?cid=6&amp;page=4">4</a></li><li><a href="/mine/public/index.php/index/products?cid=6&amp;page=5">5</a></li><li><a href="/mine/public/index.php/index/products?cid=6&amp;page=6">6</a></li> <li><a href="/mine/public/index.php/index/products?cid=6&amp;page=2">&raquo;</a></li></ul>
	<br class="clr"/>
</div>
<script type="text/javascript">  
            function check(obj){
            if(location.search){
            	if(obj=="新品"){  
                    window.location.replace(location.href+'&order=1');  
                }else if(obj=="价格升序"){  
                    window.location.replace(location.href+'&order=2');  
                }else if(obj=="价格降序"){  
                    window.location.replace(location.href+'&order=3');  
                } else if(obj=="销量由高到低"){  
                    window.location.replace(location.href+'&order=4');  
                }
            }
            else{
            	if(obj=="新品"){  
                    window.location.replace(location.href+'?order=1');  
                }else if(obj=="价格升序"){  
                    window.location.replace(location.href+'?order=2');  
                }else if(obj=="价格降序"){  
                    window.location.replace(location.href+'?order=3');  
                } else if(obj=="销量由高到低"){  
                    window.location.replace(location.href+'?order=4');  
                }
            }       
            }  
</script>

	
		
		</div>
	</div>
</div>
<!-- Footer ================================================================== -->
	<div id="footerSection">
	<div class="container">
		<div class="row">
			<div class="span3">
				<h4>账户</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/login">你的账户</a>
				<a href="__ROOT__/index.php/index/login">个人信息</a> 
				<a href="__ROOT__/index.php/index/login">收货地址</a> 
				<a href="__ROOT__/index.php/index/specialoffer">折扣信息</a>  
				<a href="__ROOT__/index.php/index/record">购买记录</a>
			 </div>
			<div class="span3">
				<h4>信息</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/contact">联系我们</a>  
				<a href="__ROOT__/index.php/index/register">注册</a>  
				<a href="__ROOT__/index.php/index/legalnotice">法律信息</a>  
				<a href="__ROOT__/index.php/index/tac">条款和条件</a> 
				<a href="__ROOT__/index.php/index/faq">常问问题</a>
			 </div>
			<div class="span3">
				<h4>优惠</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/index">新款商品</a> 
				<a href="__ROOT__/index.php/index/index">畅销品</a>  
				<a href="__ROOT__/index.php/index/specialoffer">特别优惠</a>  
				<a href="#">生产商</a> 
				<a href="#">供应商</a> 
			 </div>
			<div id="socialMedia" class="span3 pull-right">
				<h4>社交媒体 </h4>
			<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;'>
		<img class='1' style='display:none;position:absolute;top:-30px;' width="100" height="100" src="__STATIC__/themes/images/qqma.jpg"/>
	</div>
&nbsp;&nbsp;<img class='2' width="60"  height="60" src="__STATIC__/themes/images/qq.png" title="QQ" alt="QQ"/>
</div>
<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;' >
		<img width="100" height="100" class='3' style='display:none;position:absolute;top:-30px;' src="__STATIC__/themes/images/weixinma.png"/>
	</div>

&nbsp;&nbsp;<img width="60" class='4' height="60" src="__STATIC__/themes/images/weixin.png" title="微信" alt="微信"/>
</div>
<div style='float:left;'>
&nbsp;&nbsp;&nbsp;<br><br><br><br><br><a href="https://weibo.com/u/5703804590"><img width="60" height="60" src="__STATIC__/themes/images/weibo.png" title="微博" alt="微博"/></a> 
</div>

                <script>  
                $(document).ready(function(){  
                    $(".2").mouseover(function(){
                    $(".1").show();}); 
                    $(".2").mouseout(function(){$(".1").hide();});
                    $(".4").mouseover(function(){$(".3").show();});  
                    $(".4").mouseout(function(){$(".3").hide();});
                });   
                </script>  
		 </div>
         
	</div><!-- Container End -->
	</div>
</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<script src="__STATIC__/themes/js/jquery.js" type="text/javascript"></script>
	<script src="__STATIC__/themes/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="__STATIC__/themes/js/google-code-prettify/prettify.js"></script>
	
	<script src="__STATIC__/themes/js/bootshop.js"></script>
    <script src="__STATIC__/themes/js/jquery.lightbox-0.5.js"></script>
	
	<!-- Themes switcher section ============================================================================================= -->
<div id="secectionBox">
<link rel="stylesheet" href="__STATIC__/themes/switch/themeswitch.css" type="text/css" media="screen">
	<div id="themeContainer">
	<div id="hideme" class="themeTitle">主题更改</div>
	<div class="themeName">默认 主题</div>
	<div class="images style">
	<a href="__STATIC__/themes/css/#" name="bootshop"><img src="__STATIC__/themes/switch/images/clr/bootshop.png" alt="bootstrap business templates" class="active"></a>
	<a href="__STATIC__/themes/css/#" name="businessltd"><img src="__STATIC__/themes/switch/images/clr/businessltd.png" alt="bootstrap business templates" class=""></a>
	</div>
	<div class="themeName">皮肤</div>
	<div class="images style">
		<a href="__STATIC__/themes/css/#" name="amelia" title="Amelia"><img src="__STATIC__/themes/switch/images/clr/amelia.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="spruce" title="Spruce"><img src="__STATIC__/themes/switch/images/clr/spruce.png" alt="bootstrap business templates" class=""></a>
		<a href="__STATIC__/themes/css/#" name="superhero" title="Superhero"><img src="__STATIC__/themes/switch/images/clr/superhero.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cyborg"><img src="__STATIC__/themes/switch/images/clr/cyborg.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cerulean"><img src="__STATIC__/themes/switch/images/clr/cerulean.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="journal"><img src="__STATIC__/themes/switch/images/clr/journal.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="readable"><img src="__STATIC__/themes/switch/images/clr/readable.png" alt="bootstrap business templates"></a>	
		<a href="__STATIC__/themes/css/#" name="simplex"><img src="__STATIC__/themes/switch/images/clr/simplex.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="slate"><img src="__STATIC__/themes/switch/images/clr/slate.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="spacelab"><img src="__STATIC__/themes/switch/images/clr/spacelab.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="united"><img src="__STATIC__/themes/switch/images/clr/united.png" alt="bootstrap business templates"></a>
		<p style="margin:0;line-height:normal;margin-left:-10px;display:none;"><small>These are just examples and you can build your own color scheme in the backend.</small></p>
	</div>
	<div class="themeName">背景颜色 </div>
	<div class="images patterns">
		<a href="__STATIC__/themes/css/#" name="pattern1"><img src="__STATIC__/themes/switch/images/pattern/pattern1.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="pattern2"><img src="__STATIC__/themes/switch/images/pattern/pattern2.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern3"><img src="__STATIC__/themes/switch/images/pattern/pattern3.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern4"><img src="__STATIC__/themes/switch/images/pattern/pattern4.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern5"><img src="__STATIC__/themes/switch/images/pattern/pattern5.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern6"><img src="__STATIC__/themes/switch/images/pattern/pattern6.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern7"><img src="__STATIC__/themes/switch/images/pattern/pattern7.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern8"><img src="__STATIC__/themes/switch/images/pattern/pattern8.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern9"><img src="__STATIC__/themes/switch/images/pattern/pattern9.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern10"><img src="__STATIC__/themes/switch/images/pattern/pattern10.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern11"><img src="__STATIC__/themes/switch/images/pattern/pattern11.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern12"><img src="__STATIC__/themes/switch/images/pattern/pattern12.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern13"><img src="__STATIC__/themes/switch/images/pattern/pattern13.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern14"><img src="__STATIC__/themes/switch/images/pattern/pattern14.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern15"><img src="__STATIC__/themes/switch/images/pattern/pattern15.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern16"><img src="__STATIC__/themes/switch/images/pattern/pattern16.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern17"><img src="__STATIC__/themes/switch/images/pattern/pattern17.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern18"><img src="__STATIC__/themes/switch/images/pattern/pattern18.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern19"><img src="__STATIC__/themes/switch/images/pattern/pattern19.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern20"><img src="__STATIC__/themes/switch/images/pattern/pattern20.png" alt="bootstrap business templates"></a>
		 
	</div>
	</div>	
</div>
<script type="text/javascript">
jQuery(document).ready(function() {
// Pattern Selector function//////////////////////////////////	
	jQuery('.patterns a').click(function(e) {
		e.preventDefault();
			jQuery(this).parent().find('img').removeClass('active');
			jQuery(this).find('img').addClass('active');

			var name = jQuery(this).attr('name');
			
				jQuery('body').css('background', 'url(__STATIC__/themes/switch/images/pattern/'+name+'.png) repeat center center scroll');
				jQuery('body').css('background-size', 'auto');
	});
// Style Selector function ////////////////////////////////////
	jQuery('.style a').click(function(e) {
		e.preventDefault();
		jQuery(this).parent().find('img').removeClass('active');
		jQuery(this).find('img').addClass('active');

		var name = jQuery(this).attr('name');

		if(name == 'green') {
			jQuery('#callCss').attr('href', '');
		} else {
			jQuery('#callCss').attr('href', 'http://localhost:8080/mine/public/static/themes/'+name+'/bootstrap.min.css');
		}

	});
	
	/* Settings Button */
	$('#themesBtn').click(function() {
	  $('#secectionBox').animate({
		right:'0'
	  }, 500, function() {
		// Animation complete.
	  });
	  $('#themesBtn').animate({
		right:'-80'
	  }, 100, function() {
		// Animation complete.
	  });
	}); 


	$('#hideme').click(function() {
		$('#secectionBox').animate({
		right:'-999'
	  }, 500, function() {
		// Animation complete.
	  });
	  
	  $('#themesBtn').animate({
		right:'0'
	  }, 700, function() {
		// Animation complete.
	  }); 
	});

});
</script>
<span id="themesBtn"></span>
</body></html><?php }
}
