<?php
/* Smarty version 3.1.32, created on 2018-06-07 14:04:34
  from 'C:\wamp64\www\mine\application\admin\view\login\login.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b18caf200a2a8_81698726',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0dc37a219e258973e9afcf78048e0a0126207958' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\admin\\view\\login\\login.html',
      1 => 1528351425,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b18caf200a2a8_81698726 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>后台登录</title>
	<link href="__STATIC__/admin/css/admin.css" rel="stylesheet" />
	<?php echo '<script'; ?>
 src="__STATIC__/admin/js/jquery-3.3.1.js"><?php echo '</script'; ?>
>
</head>
<body class="login">
	<div class="login_box">
	<form method="post" action="">
		<h1>欢迎访问后台</h1>
		<table>
			<tr><th width="80">用户名：</th><td><input class="input" type="text" name="admin_name" /></td></tr>
			<tr><th>密　码：</th><td><input class="input" type="password" name="admin_pwd" /></td></tr>
			<tr><th>验证码：</th><td><input class="input" type="text" name="verify" /></td></tr>
			<tr><td>&nbsp;</td><td><img src="__ROOT__/index.php/admin/login/getCaptcha" id='captcha' style="cursor: pointer;"/></td></tr>
			<tr><td>&nbsp;</td><td><input class="login_btn" type="submit" value="登录" name='sm'/></td></tr>
		</table>
	</form>
	</div>
	<?php echo '<script'; ?>
 type="text/javascript">
	$("#captcha").click(function(){
			$(this).attr('src', "__ROOT__/index.php/admin/login/getCaptcha");
			});
	<?php echo '</script'; ?>
>
</body>
</html><?php }
}
