<?php
/* Smarty version 3.1.32, created on 2018-07-08 15:23:56
  from 'C:\wamp64\www\mine\application\index\view\transfer\transfer.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b41bc0cd27e06_23579011',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '02efeff1ae5c9c3688c424674291c58207576e6a' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\application\\index\\view\\transfer\\transfer.html',
      1 => 1528520117,
      2 => 'file',
    ),
    '6e1452b4c661213e182963508266af1b04b388d2' => 
    array (
      0 => 'C:\\wamp64\\www\\mine\\public\\model.html',
      1 => 1529643556,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:model.html' => 1,
  ),
),false)) {
function content_5b41bc0cd27e06_23579011 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_172585b41bc0cd0ba22_94104821', "span9");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "model.html", '6e1452b4c661213e182963508266af1b04b388d2', 'content_5b41bc0cb06484_01963054');
}
/* {block "span9"} */
class Block_172585b41bc0cd0ba22_94104821 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'span9' => 
  array (
    0 => 'Block_172585b41bc0cd0ba22_94104821',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="span9" id="mainCol">
    <ul class="breadcrumb">
		<li><a href="__ROOT__/index.php/index/">主页</a> <span class="divider">/</span></li>
		<li class="active">物流详情</li>
    </ul>
	<h3> 物流详情</h3>	
	<hr class="soft"/>
	<h5>该功能暂未开发</h5><br/>
	<p>
	党的十八大提出，倡导富强、民主、文明、和谐，倡导自由
、平等、公正、法治，倡导爱国、敬业、诚信、友善，积极培育和践行社会主义核心价值观。富强、民主、文明、和谐是国家层面的价值目标，自由、平等、公正、法治是社会层面的价值取向，爱国、敬业、诚信、友善是公民个人层面的价值准则，这24个字是社会主义核心价值观的基本内容。
</p>
<h5>富强、民主、文明、和谐</h5><br/>
<p>
“富强、民主、文明、和谐”，是我国社会主义现代化国家的建设目标，也是从价值目标层面对社会主义核心价值观基本理念的凝练，在社会主义核心价值观中居于最高层次，对其他层次的价值理念具有统领作用。富强即国富民强，是社会主义现代化国家经济建设的应然状态，是中华民族梦寐以求的美好夙愿，也是国家繁荣昌盛、人民幸福安康的物质基础。民主是人类社会的美好诉求。我们追求的民主是人民民主，其实质和核心是人民当家作主。它是社会主义的生命，也是创造人民美好幸福生活的政治保障。文明是社会进步的重要标志，也是社会主义现代化国家的重要特征。它是社会主义现代化国家文化建设的应有状态，是对面向现代化、面向世界、面向未来的，民族的科学的大众的社会主义文化的概括，是实现中华民族伟大复兴的重要支撑。和谐是中国传统文化的基本理念，集中体现了学有所教、劳有所得、病有所医、老有所养、住有所居的生动局面。它是社会主义现代化国家在社会建设领域的价值诉求，是经济社会和谐稳定、持续健康发展的重要保证。
</p>
<h5>自由、平等、公正、法治</h5><br/>
<p>
“自由、平等、公正、法治”，是对美好社会的生动表述，也是从社会层面对社会主义核心价值观基本理念的凝练。它反映了中国特色社会主义的基本属性，是我们党矢志不渝、长期实践的核心价值理念。自由是指人的意志自由、存在和发展的自由，是人类社会的美好向往，也是马克思主义追求的社会价值目标。平等指的是公民在法律面前的一律平等，其价值取向是不断实现实质平等。它要求尊重和保障人权，人人依法享有平等参与、平等发展的权利。公正即社会公平和正义，它以人的解放、人的自由平等权利的获得为前提，是国家、社会应然的根本价值理念。法治是治国理政的基本方式，依法治国是社会主义民主政治的基本要求。它通过法制建设来维护和保障公民的根本利益，是实现自由平等、公平正义的制度保证。
	</p>
	<h5>爱国、敬业、诚信、友善</h5><br/>
<p>
“爱国、敬业、诚信、友善”，是公民基本道德规范，是从个人行为层面对社会主义核心价值观基本理念的凝练。它覆盖社会道德生活的各个领域，是公民必须恪守的基本道德准则，也是评价公民道德行为选择的基本价值标准。爱国是基于个人对自己祖国依赖关系的深厚情感，也是调节个人与祖国关系的行为准则。它同社会主义紧密结合在一起，要求人们以振兴中华为己任，促进民族团结、维护祖国统一、自觉报效祖国。敬业是对公民职业行为准则的价值评价，要求公民忠于职守，克己奉公，服务人民，服务社会，充分体现了社会主义职业精神。诚信即诚实守信，是人类社会千百年传承下来的道德传统，也是社会主义道德建设的重点内容，它强调诚实劳动、信守承诺、诚恳待人。友善强调公民之间应互相尊重、互相关心、互相帮助，和睦友好，努力形成社会主义的新型人际关系。
</p>
</div>
<?php
}
}
/* {/block "span9"} */
/* Start inline template "C:\wamp64\www\mine\public\model.html" =============================*/
function content_5b41bc0cb06484_01963054 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<html lang="en"><head>
    <meta charset="utf-8">
    <title>Yuann shop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">	
<!-- Bootstrap style --> 
    <link id="callCss" rel="stylesheet" href="__STATIC__/themes/bootshop/bootstrap.min.css" media="screen">
    <link href="__STATIC__/themes/css/base.css" rel="stylesheet" media="screen">
<!-- Bootstrap style responsive -->	
	<link href="__STATIC__/themes/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="__STATIC__/themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->	
	<link href="__STATIC__/themes/js/google-code-prettify/prettify.css" rel="stylesheet">
<!-- fav and touch icons -->
    <link rel="shortcut icon" href="__STATIC__/themes/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="__STATIC__/themes/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="__STATIC__/themes/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="__STATIC__/themes/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="__STATIC__/themes/images/ico/apple-touch-icon-57-precomposed.png">
	<style type="text/css" id="enject"></style>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery-3.3.1.js" type="text/javascript"><?php echo '</script'; ?>
>
  <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_243835b41bc0cb278a0_19138476', "style");
?>

  </head>
<body>
<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
	<div class="span6">
	欢迎<strong> <?php echo session('user');?>
</strong>
	<a href="__ROOT__/index.php/index/login/logout"><span class="btn btn-mini btn-primary">退出登录  </span> </a> 
	</div>
	<div class="span6">
	<div class="pull-right cart-data">
		<a href="__ROOT__/index.php/index/record"><span class="btn btn-mini "><i class="icon-shopping-cart icon-white"></i> 购买记录  </span></a>
		<span class="btn btn-mini sum">￥<?php echo session('sum');?>
</span>
		<a href="__ROOT__/index.php/index/login"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> 购物车  </span> </a> 
	</div>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" href="__ROOT__/index.php/index/"><img src="__STATIC__/themes/images/logo.png" alt="Bootsshop"></a>
		<form class="form-inline navbar-search" method="get" action="__ROOT__/index.php/index/products">
		<input id="srchFld" class="srchTxt" name='key' type="text" style="width:200px;height:30px">
		  <select class="srchTxt" name='factor'>
			<option value='所有'>所有</option>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, session('kinds'), 'value', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
			<option value='<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
'><?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</option>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            
		</select> 
		  <button type="submit" id="submitButton" name='search' class="btn btn-primary">搜索</button>
    </form>
    <ul id="topMenu" class="nav pull-right">
	 <li class=""><a href="__ROOT__/index.php/index/specialoffer">特价优惠</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/transfer">物流详情</a></li>
	 <li class=""><a href="__ROOT__/index.php/index/contact">联系我</a></li>
	 <li class="">
	 <a href="__ROOT__/index.php/index/login" role="button"  style="padding-right:0"><span class="btn btn-large btn-success">登录</span></a>
	</li>
    </ul>
  </div>
</div>
</div>
</div>
<!-- Header End====================================================================== -->

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_286845b41bc0cbe0876_50731647', "carouselBlk");
?>


<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<div id="sidebar" class="span3">
		<div class="well well-small cart-data"><a id="myCart"  href="__ROOT__/index.php/index/login"><img src="__STATIC__/themes/images/ico-cart.png" alt="cart"><span class='count'><?php echo session('count');?>
种商品</span>  <span class="badge badge-warning pull-right sum"><span class='sum'>￥<?php echo session('sum');?>
</span></span></a></div>
		<br>
		<ul id="sideManu" class="nav nav-tabs nav-stacked">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, session('kinds'), 'value', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
?>
			<li class="subMenu open"><a> <?php echo $_smarty_tpl->tpl_vars['key']->value;?>
</a>
				<ul>
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['value']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
						<li><a href="__ROOT__/index.php/index/products?cid=<?php echo $_smarty_tpl->tpl_vars['row']->value['cid'];?>
"><i class="icon-chevron-right"></i><?php echo $_smarty_tpl->tpl_vars['row']->value['cname'];?>
</a></li>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</ul>
			</li>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ul>
		<br>
		<br>
			<div class="thumbnail">
			<h4 style='text-align:center; color:red;'>销量冠军</h4>
				<img src="__STATIC__/imgs/computer/peripherals/45140873352/1.jpg" title="Bootshop New Kindel" alt="Bootshop Kindel">
				<div class="caption">
				  <h5>陈子豪外设店宜博M639电竞机械鼠标电脑有线吃鸡游戏宏绝地求生</h5>
				    <h4 style="text-align:center"><a class="btn" href="__ROOT__/index.php/index/productdetail/index?gid=45140873352"> <i class="icon-zoom-in"></i></a> <a class="btn" href="productdetail?gid=45140873352">加入 <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="productdetail?gid=45140873352">￥107</a></h4>
				</div>
			  </div><br><br>
			<div class="thumbnail">
				<img src="__STATIC__/themes/images/payment_methods.png" title="Bootshop 支付方式" alt="Payments Methods">
				<div class="caption">
				  <h5>支付方式</h5>
				</div>
			  </div>
	</div>
<!-- Sidebar end=============================================== -->
		
		
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_34135b41bc0ccbdd29_53325416', "span9");
?>

		
		</div>
	</div>
</div>
<!-- Footer ================================================================== -->
	<div id="footerSection">
	<div class="container">
		<div class="row">
			<div class="span3">
				<h4>账户</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/login">你的账户</a>
				<a href="__ROOT__/index.php/index/login">个人信息</a> 
				<a href="__ROOT__/index.php/index/login">收货地址</a> 
				<a href="__ROOT__/index.php/index/specialoffer">折扣信息</a>  
				<a href="__ROOT__/index.php/index/record">购买记录</a>
			 </div>
			<div class="span3">
				<h4>信息</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/contact">联系我们</a>  
				<a href="__ROOT__/index.php/index/register">注册</a>  
				<a href="__ROOT__/index.php/index/legalnotice">法律信息</a>  
				<a href="__ROOT__/index.php/index/tac">条款和条件</a> 
				<a href="__ROOT__/index.php/index/faq">常问问题</a>
			 </div>
			<div class="span3">
				<h4>优惠</h4>
				<br><br>
				<a href="__ROOT__/index.php/index/index">新款商品</a> 
				<a href="__ROOT__/index.php/index/index">畅销品</a>  
				<a href="__ROOT__/index.php/index/specialoffer">特别优惠</a>  
				<a href="#">生产商</a> 
				<a href="#">供应商</a> 
			 </div>
			<div id="socialMedia" class="span3 pull-right">
				<h4>社交媒体 </h4>
			<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;'>
		<img class='1' style='display:none;position:absolute;top:-30px;' width="100" height="100" src="__STATIC__/themes/images/qqma.jpg"/>
	</div>
&nbsp;&nbsp;<img class='2' width="60"  height="60" src="__STATIC__/themes/images/qq.png" title="QQ" alt="QQ"/>
</div>
<div style='float:left;'>
	<div style='width:100px; height:100px;position:relative;' >
		<img width="100" height="100" class='3' style='display:none;position:absolute;top:-30px;' src="__STATIC__/themes/images/weixinma.png"/>
	</div>

&nbsp;&nbsp;<img width="60" class='4' height="60" src="__STATIC__/themes/images/weixin.png" title="微信" alt="微信"/>
</div>
<div style='float:left;'>
&nbsp;&nbsp;&nbsp;<br><br><br><br><br><a href="https://weibo.com/u/5703804590"><img width="60" height="60" src="__STATIC__/themes/images/weibo.png" title="微博" alt="微博"/></a> 
</div>

                <?php echo '<script'; ?>
>  
                $(document).ready(function(){  
                    $(".2").mouseover(function(){
                    $(".1").show();}); 
                    $(".2").mouseout(function(){$(".1").hide();});
                    $(".4").mouseover(function(){$(".3").show();});  
                    $(".4").mouseout(function(){$(".3").hide();});
                });   
                <?php echo '</script'; ?>
>  
		 </div>
         
	</div><!-- Container End -->
	</div>
</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/google-code-prettify/prettify.js"><?php echo '</script'; ?>
>
	
	<?php echo '<script'; ?>
 src="__STATIC__/themes/js/bootshop.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="__STATIC__/themes/js/jquery.lightbox-0.5.js"><?php echo '</script'; ?>
>
	
	<!-- Themes switcher section ============================================================================================= -->
<div id="secectionBox">
<link rel="stylesheet" href="__STATIC__/themes/switch/themeswitch.css" type="text/css" media="screen">
	<div id="themeContainer">
	<div id="hideme" class="themeTitle">主题更改</div>
	<div class="themeName">默认 主题</div>
	<div class="images style">
	<a href="__STATIC__/themes/css/#" name="bootshop"><img src="__STATIC__/themes/switch/images/clr/bootshop.png" alt="bootstrap business templates" class="active"></a>
	<a href="__STATIC__/themes/css/#" name="businessltd"><img src="__STATIC__/themes/switch/images/clr/businessltd.png" alt="bootstrap business templates" class=""></a>
	</div>
	<div class="themeName">皮肤</div>
	<div class="images style">
		<a href="__STATIC__/themes/css/#" name="amelia" title="Amelia"><img src="__STATIC__/themes/switch/images/clr/amelia.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="spruce" title="Spruce"><img src="__STATIC__/themes/switch/images/clr/spruce.png" alt="bootstrap business templates" class=""></a>
		<a href="__STATIC__/themes/css/#" name="superhero" title="Superhero"><img src="__STATIC__/themes/switch/images/clr/superhero.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cyborg"><img src="__STATIC__/themes/switch/images/clr/cyborg.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="cerulean"><img src="__STATIC__/themes/switch/images/clr/cerulean.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="journal"><img src="__STATIC__/themes/switch/images/clr/journal.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="readable"><img src="__STATIC__/themes/switch/images/clr/readable.png" alt="bootstrap business templates"></a>	
		<a href="__STATIC__/themes/css/#" name="simplex"><img src="__STATIC__/themes/switch/images/clr/simplex.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="slate"><img src="__STATIC__/themes/switch/images/clr/slate.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="spacelab"><img src="__STATIC__/themes/switch/images/clr/spacelab.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="united"><img src="__STATIC__/themes/switch/images/clr/united.png" alt="bootstrap business templates"></a>
		<p style="margin:0;line-height:normal;margin-left:-10px;display:none;"><small>These are just examples and you can build your own color scheme in the backend.</small></p>
	</div>
	<div class="themeName">背景颜色 </div>
	<div class="images patterns">
		<a href="__STATIC__/themes/css/#" name="pattern1"><img src="__STATIC__/themes/switch/images/pattern/pattern1.png" alt="bootstrap business templates" class="active"></a>
		<a href="__STATIC__/themes/css/#" name="pattern2"><img src="__STATIC__/themes/switch/images/pattern/pattern2.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern3"><img src="__STATIC__/themes/switch/images/pattern/pattern3.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern4"><img src="__STATIC__/themes/switch/images/pattern/pattern4.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern5"><img src="__STATIC__/themes/switch/images/pattern/pattern5.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern6"><img src="__STATIC__/themes/switch/images/pattern/pattern6.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern7"><img src="__STATIC__/themes/switch/images/pattern/pattern7.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern8"><img src="__STATIC__/themes/switch/images/pattern/pattern8.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern9"><img src="__STATIC__/themes/switch/images/pattern/pattern9.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern10"><img src="__STATIC__/themes/switch/images/pattern/pattern10.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern11"><img src="__STATIC__/themes/switch/images/pattern/pattern11.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern12"><img src="__STATIC__/themes/switch/images/pattern/pattern12.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern13"><img src="__STATIC__/themes/switch/images/pattern/pattern13.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern14"><img src="__STATIC__/themes/switch/images/pattern/pattern14.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern15"><img src="__STATIC__/themes/switch/images/pattern/pattern15.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern16"><img src="__STATIC__/themes/switch/images/pattern/pattern16.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern17"><img src="__STATIC__/themes/switch/images/pattern/pattern17.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern18"><img src="__STATIC__/themes/switch/images/pattern/pattern18.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern19"><img src="__STATIC__/themes/switch/images/pattern/pattern19.png" alt="bootstrap business templates"></a>
		<a href="__STATIC__/themes/css/#" name="pattern20"><img src="__STATIC__/themes/switch/images/pattern/pattern20.png" alt="bootstrap business templates"></a>
		 
	</div>
	</div>	
</div>
<?php echo '<script'; ?>
 type="text/javascript">
jQuery(document).ready(function() {
// Pattern Selector function//////////////////////////////////	
	jQuery('.patterns a').click(function(e) {
		e.preventDefault();
			jQuery(this).parent().find('img').removeClass('active');
			jQuery(this).find('img').addClass('active');

			var name = jQuery(this).attr('name');
			
				jQuery('body').css('background', 'url(__STATIC__/themes/switch/images/pattern/'+name+'.png) repeat center center scroll');
				jQuery('body').css('background-size', 'auto');
	});
// Style Selector function ////////////////////////////////////
	jQuery('.style a').click(function(e) {
		e.preventDefault();
		jQuery(this).parent().find('img').removeClass('active');
		jQuery(this).find('img').addClass('active');

		var name = jQuery(this).attr('name');

		if(name == 'green') {
			jQuery('#callCss').attr('href', '');
		} else {
			jQuery('#callCss').attr('href', 'http://localhost:8080/mine/public/static/themes/'+name+'/bootstrap.min.css');
		}

	});
	
	/* Settings Button */
	$('#themesBtn').click(function() {
	  $('#secectionBox').animate({
		right:'0'
	  }, 500, function() {
		// Animation complete.
	  });
	  $('#themesBtn').animate({
		right:'-80'
	  }, 100, function() {
		// Animation complete.
	  });
	}); 


	$('#hideme').click(function() {
		$('#secectionBox').animate({
		right:'-999'
	  }, 500, function() {
		// Animation complete.
	  });
	  
	  $('#themesBtn').animate({
		right:'0'
	  }, 700, function() {
		// Animation complete.
	  }); 
	});

});
<?php echo '</script'; ?>
>
<span id="themesBtn"></span>
</body></html><?php
}
/* {block "style"} */
class Block_243835b41bc0cb278a0_19138476 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_243835b41bc0cb278a0_19138476',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "style"} */
/* {block "carouselBlk"} */
class Block_286845b41bc0cbe0876_50731647 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'carouselBlk' => 
  array (
    0 => 'Block_286845b41bc0cbe0876_50731647',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block "carouselBlk"} */
/* {block "span9"} */
class Block_34135b41bc0ccbdd29_53325416 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'span9' => 
  array (
    0 => 'Block_34135b41bc0ccbdd29_53325416',
  ),
);
public $callsChild = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		<?php 
$_smarty_tpl->inheritance->callChild($_smarty_tpl, $this);
?>

	<?php
}
}
/* {/block "span9"} */
/* End inline template "C:\wamp64\www\mine\public\model.html" =============================*/
}
