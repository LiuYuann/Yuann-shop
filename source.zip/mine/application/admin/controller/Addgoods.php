<?php
namespace app\admin\controller;
use think\Db;
use think\Controller;
use think\Exception;
class Addgoods extends Controller
{
    public function index()
    {
        if (session('?admin_name'))
        {
            $category=Db::query('SELECT DISTINCT pcname FROM itcast_category;');
            foreach ($category as $row){
                $kind=Db::query('SELECT cname,cid FROM itcast_category where pcname=:pcname;',["pcname"=>$row['pcname']]);
                $kinds[$row['pcname']]=$kind;
            }
            if(input('?post.sm'))
            {
                $gid=input('post.gid');
                $gname=input('post.gname');
                $gid=input('post.gid');
                $price=(int)input('post.price');
                $stock=(int)input('post.stock');
                $status=input('post.status');
                $description=input('post.description');
                $cid=input('post.cid');
                switch ($cid)
                {
                    case 1: $thumb='computer/whole machine//'.$gid;break;
                    case 2: $thumb='computer/accessories/'.$gid;break;
                    case 3: $thumb='computer/peripherals/'.$gid;break;
                    case 4: $thumb='computer/office equipment/'.$gid;break;
                    case 5: $thumb='phone/phone/'.$gid;break;
                    case 6: $thumb='phone/accessories/'.$gid;break;
                    case 7: $thumb='photography/SLR/'.$gid;break;
                    case 8: $thumb='photography/micro-camera/'.$gid;break;
                    case 9: $thumb='photography/video camera/'.$gid;break;
                    case 10: $thumb='photography/digital camera/'.$gid;break;
                    case 11: $thumb='entertainment/headset/'.$gid;break;
                    case 12: $thumb='entertainment/speakers/'.$gid;break;
                    case 13: $thumb='entertainment/microphone/'.$gid;break;
                    case 14: $thumb='smart device/smart bracelet/'.$gid;break;
                    case 15: $thumb='smart device/smart glasses/'.$gid;break;
                    case 16: $thumb='smart device/smart robot/'.$gid;break;
                }
                $sales=0;   
                $data=['gname'=>$gname,'price'=>$price,'stock'=>$stock,'status'=>$status,
                    'description'=>$description,'sales'=>$sales,'cid'=>$cid,'gid'=>$gid,'thumb'=>$thumb];
                try {
                       $msg=Db::table('itcast_goods')->where('gid',$gid)->insert($data);
                }
                catch (Exception $e){
                    echo "该商品已经添加";
                    return $this->redirect('__ROOT__/index.php/admin/showgoods/editgoods',['gid'=>$gid]);
                }
                if ($msg)
                {
                    $files = request()->file('img');
                    $i=1;
                    foreach($files as $file){
                        // 移动到框架应用根目录/public/static/imgs/ 目录下
                        $info = $file->validate(['size'=>4194304,'ext'=>'jpg,png,gif'])->move(ROOT_PATH . 'public' . DS . 'static/imgs/'.$thumb,$i.'.jpg');
                        
                        $i++;
                        if(!$info){
                            return $this->error($file->getError(),'showgoods/editgoods');
                        }
                    }
                    return $this->success('添加商品成功','addgoods/index')  ;
                }
                else
                {
                    return $this->error('添加商品失败','addgoods/index')   ;
                }
            }
            else
            {
                return view('addgoods',['kinds'=>$kinds]);
            }
        }
        else
        {
            $this->redirect('login/index');
        }        
    }
}