<?php
namespace app\admin\controller;
use think\Db;
use think\Controller;
class Member extends Controller
{
    public function index()
    {
        if (session('?admin_name'))
        {
            $members=Db::table('itcast_member')->paginate(9,false,['query' => request()->param()]);
            $page=$members->render();
            return view('Member-index',['members'=>$members,'page'=>$page]);
        }
        else
        {
            $this->redirect('login/index');
        }
    }
    public function detail()
    {
        $mid=input('get.mid');
        $member=Db::table('itcast_member')->join('itcast_address','itcast_address.mid=itcast_member.mid')->where('itcast_member.mid',$mid)->find();
        $record=Db::table('itcast_record')->join('itcast_goods','itcast_goods.gid=itcast_record.gid')->where('itcast_record.mid',$mid)->order('time','desc')->paginate(9,false,['query' => request()->param()]);
        $page=$record->render();
        return view('Member-detail',['member'=>$member,'record'=>$record,'page'=>$page]);
    }
    
}