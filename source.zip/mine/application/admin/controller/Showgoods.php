<?php
namespace app\admin\controller;
use think\Db;
use think\Controller;
class Showgoods extends Controller
{
    public function index()
    {
        if (session('?admin_name'))
        {
            $category=Db::query('SELECT DISTINCT pcname FROM itcast_category;');
            foreach ($category as $row){
                $kind=Db::query('SELECT cname,cid FROM itcast_category where pcname=:pcname;',["pcname"=>$row['pcname']]);
                $kinds[$row['pcname']]=$kind;
            }
            $cid = input('get.cid');
            $order=input('get.order');//排序方式，1默认，2价格降序，3价格降序，4销量降序
            if($cid)
            {
                if(is_numeric( $cid ) )
                {
                    $goods=Db::table('itcast_goods')->where('cid',$cid);
                }
                elseif ($cid!='所有')
                {
                    $goods=Db::table('itcast_goods')->join('itcast_category','itcast_goods.cid=itcast_category.cid')->where('itcast_category.pcname',$cid);
                }
                else
                {
                    $goods=Db::table('itcast_goods');
                }
            }
            else
            {
                $goods=Db::table('itcast_goods');
            }
            switch ($order){
                case '1':
                    $goods=$goods->order('turn desc')->paginate(9,false,['query' => request()->param()]);
                    break;
                case 2:
                    $goods=$goods->order('price asc')->paginate(9,false,['query' => request()->param()]);
                    break;
                case 3:
                    $goods=$goods->order('price desc')->paginate(9,false,['query' => request()->param()]);
                    break;
                case 4:
                    $goods=$goods->order('sales desc')->paginate(9,false,['query' => request()->param()]);
                    break;
                default:
                    $goods=$goods->paginate(9,false,['query' => request()->param()]);
                    break;
            }
            $page=$goods->render();
            return view('Goods-index',['goods'=>$goods,'page'=>$page,'kinds'=>$kinds]);
        }
        else
        {
            $this->redirect('login/index');
        }
        
    }
    public function editGoods()
    {
        $gid=input('get.gid');
        $goods=Db::table('itcast_goods')->where('gid',$gid)->find();
        $discount=Db::table('itcast_discountgoods')->where('gid',$gid)->find();
        if ($discount==NULL)
        {
            $discount['discount']=0;
        }
        if (session('?admin_name'))
        {
            if(input('?post.sm'))
            {
                $gname=input('post.gname');
                $gid=input('post.gid');
                $price=input('post.price');
                $stock=input('post.stock');
                $status=input('post.status');
                $description=input('post.description');
                $thumb=input('post.thumb');
                $files = request()->file('img');
                $i=1;
                foreach($files as $file){
                    // 移动到框架应用根目录/public/uploads/ 目录下
                    $info = $file->validate(['size'=>4194304,'ext'=>'jpg,png,gif'])->move(ROOT_PATH . 'public' . DS . 'static/imgs/'.$thumb,$i.'.jpg');
                    if(!$info){
                        return $this->error($file->getError(),'showgoods/editgoods');
                    }
                }
                $data=['gname'=>$gname,'price'=>$price,'stock'=>$stock,'status'=>$status,'description'=>$description];
                $msg=Db::table('itcast_goods')->where('gid',$gid)->update($data);
                return view('editgoods',['goods'=>$goods,'discount'=>$discount]);
            }
            else
            {
                $gid=input('get.gid');
                $goods=Db::table('itcast_goods')->where('gid',$gid)->find();
                $discount=Db::table('itcast_discountgoods')->where('gid',$gid)->find();
                if ($discount==NULL)
                {
                    $discount['discount']=0;
                }
                return view('editgoods',['goods'=>$goods,'discount'=>$discount]);
            }
        }
        else
        {
            $this->redirect('login/index');
        }
        
    }
    /*删除文件夹以及其下的所有文件  */
    public function deldir($dir) {
        //先删除目录下的文件：
        $dh = opendir($dir);
        while ($file = readdir($dh)) {
            if($file != "." && $file!="..") {
                $fullpath = $dir."/".$file;
                if(!is_dir($fullpath)) {
                    unlink($fullpath);
                } else {
                    deldir($fullpath);
                }
            }
        }
        closedir($dh);
        
        //删除当前文件夹：
        if(rmdir($dir)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function delGoods()
    {
        $gid = input('get.gid');
        $d=Db::table('itcast_goods')->where('gid',$gid)->column('thumb');
        $dir=ROOT_PATH . 'public' . DS . 'static/imgs/'.$d['0'];
        $msg=Db::table('itcast_goods')->where('gid',$gid)->delete();
        if(!$this->deldir($dir))
        {
            $msg=0;
        }
        echo json_encode($msg);
    }
}