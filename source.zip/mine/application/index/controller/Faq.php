<?php
namespace app\index\controller;
class Faq
{
    public function index()
    {
        return view('faq');
    }
}