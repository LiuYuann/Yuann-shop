<?php
namespace app\index\controller;
use think\Db;
use think\Controller;
class Products extends Controller
{
    public function index()
    {
        $cid = input('get.cid');
        $order=input('get.order');//排序方式，1默认，2价格降序，3价格降序，4销量降序
        if(input('?get.search'))
        {
            $key=input('get.key');
            $factor=input('get.factor');
            $products=$this->findGoodsbyname($key,$factor);
        }
        else
        {
            $products=Db::table('itcast_goods');
        }
        if($cid)
        {
            $product=$products->where('cid',$cid);
        }
        else
        {
            $product=$products;
        }
        switch ($order){
            case 1:
                $products=$product->paginate(9,false,['query' => request()->param()]);
                break;
            case 2:
                $products=$product->order('price asc')->paginate(9,false,['query' => request()->param()]);
                break;
            case 3:
                $products=$product->order('price desc')->paginate(9,false,['query' => request()->param()]);
                break;
            case 4:
                $products=$product->order('sales desc')->paginate(9,false,['query' => request()->param()]);
                break;
            default:
                $products=$product->paginate(9,false,['query' => request()->param()]);
                break;
        }
        $page = $products->render();
        return view('products',['products'=>$products,'page'=>$page]);
    }
    
    
    public function findGoodsbyname($key,$factor)
    {
        if($factor=='所有')
        {
            $products=Db::table('itcast_goods')->where('gname', 'like', '%'.$key.'%' )->where('status','yes');
        }
        else
        {
            $products=Db::table('itcast_goods')->join('itcast_category','itcast_goods.cid=itcast_category.cid')->where('gname', 'like', '%'.$key.'%' )->where('itcast_category.pcname',$factor)->where('status','yes');
        }
        return $products;
    }
}