<?php
namespace app\index\controller;
class Transfer
{
    public function index()
    {
        return view('transfer');
    }
}