<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Exception;
class Register extends Controller
{
    public function index($email='')
    {
        if(input('?post.register')){
            $mid0=Db::query("SELECT MAX(mid) FROM itcast_member ");
            $mid=$mid0[0]['MAX(mid)']+1;
            $user=input('post.user');
            $email=input('post.email');
            $pwd=input('post.pwd');
            $birthday=input('post.birthday');
            $aid0=Db::query("SELECT MAX(aid) FROM itcast_address ");
            $aid=$aid0[0]['MAX(aid)']+1;
            $consignee=input('post.consignee');
            $phone=input('post.phone');
            $postcode=input('post.postcode');
            $findemail=Db::table('itcast_member')->where('email',$email)->select();
            if (!$findemail)
            {
                if(strlen($postcode)<=6 &&  is_numeric($postcode)){
                    $address=input('post.address');
                    $freight=rand(10,15);//运费是一个10-15的随机整数
                    $info1=Db::execute("insert into itcast_member values (:mid,:user, :email , :pwd ,:birthday)",["mid"=>$mid,"user"=>$user,'email'=>$email,'pwd'=>$pwd,'birthday'=>$birthday]);
                    $info2=Db::execute("insert into itcast_address values (:aid,:mid,:consignee, :phone , :postcode ,:address,:freight)",["aid"=>$aid,"mid"=>$mid,"consignee"=>$consignee,'phone'=>$phone,'postcode'=>$postcode,'address'=>$address,'freight'=>$freight]);
                    if($info1+$info2==2){
                        return $this->success('注册成功，请登录',"login/index");
                    }
                    else{
                        return $this->error('注册失败',"index");
                    }
                    
                }
                else
                {
                    return $this->error('邮政编码输入错误，注册失败',"index");
                }
            }
            else 
            {
                return $this->error('注册失败,该用户已经存在',"index");
            }
        }
        else{
            return view('register',['email'=>$email]);
        }
    }
}