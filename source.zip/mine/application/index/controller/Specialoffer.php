<?php
namespace app\index\controller;
use think\Db;
use think\Controller;
class Specialoffer extends Controller
{
    public function index()
    {
        $products=Db::table('itcast_discountgoods')->join('itcast_goods','itcast_goods.gid=itcast_discountgoods.gid')->paginate(9,false,['query' => request()->param()]);
        $page = $products->render();
        return view('specialoffer',['products'=>$products,'page'=>$page]);
    }
}