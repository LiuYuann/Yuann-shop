<?php
namespace app\index\controller;
class Tac
{
    public function index()
    {
        return view('tac');
    }
}