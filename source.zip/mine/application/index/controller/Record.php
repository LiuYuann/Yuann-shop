<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
class Record extends Controller
{
    public function index()
    {
        if (session('?mid'))
        {
            $record=Db::table('itcast_record')->join('itcast_goods','itcast_goods.gid=itcast_record.gid')->where('itcast_record.mid',session('mid'))->order('time','desc')->paginate(9,false,['query' => request()->param()]);
            $page=$record->render();
            $recordCount=Db::table('itcast_record')->where('mid',session('mid'))->count();
            return view('record',['record'=>$record,'page'=>$page,'recordCount'=>$recordCount]);
        }
        else
        {
            return $this->error('清先登录您的账户',"login/index");
        }
        
    }
}