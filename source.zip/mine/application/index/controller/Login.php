<?php
namespace app\index\controller;
use think\Controller;
use think\captcha\Captcha;
use think\Db;
class Login extends Controller
{
    public function index()
    {
        if (input('?post.create')){
            return $this->redirect('register/index',['email'=>input('post.email1')]);
        }
        elseif(input('?post.sm')){
            $email=input('post.email2');
            $pwd=input('post.pwd');
            $info=Db::query("select mid,user from itcast_member where email=:email and pwd=:pwd ",["email"=>$email,'pwd'=>$pwd]);
            $cap=input('post.captcha');
            $cp=$this->check_verify($cap);
            if(empty($info[0])){
                return $this->error('登陆失败',"index");
            }
            else{
                if($cp){
                    session('user',$info[0]['user']);
                    session('mid',$info[0]['mid']);
//                  获得购物车商品数量和总价
                    $sum=0;
                    $count=0;
                    $freight=Db::table('itcast_address')->where('mid',session('mid'))->column('freight');
                    $count=Db::table('itcast_shopcart_goods')->where('mid',session('mid'))->count();
                    $S=Db::table('itcast_shopcart_goods')->where('mid',session('mid'))->column('price,num');
                    foreach ($S as $key=>$value)
                    {
                        $sum+=$key*$value;
                    }
                    $sum+=$count*$freight[0];
                    session('count',$count);//商品种类
                    session('sum',$sum);//总价
                    
                    return $this->success('登陆成功','shopcart/index');
                }
                else {
                    return $this->error('登陆失败,验证码错误',"index");
                }
            }
        }
        elseif(session('?user'))
        {
            if (!session('?mid') or session('user')=='请登陆'){
                return view("login");
            }
            else{
                return $this->redirect('shopcart/index');
            }
        }
        else{
            return view("login");
        }
    }
    
    public function logout()
    {
        session('mid', null);
        session('user','请登陆');
        return $this->redirect('index/index');
    }
    
    public function getCaptcha()
    {
        $captcha = new Captcha();
        return $captcha->entry();
    }
    public function check_verify($code, $id = '')
    {
        $captcha = new Captcha();
        return $captcha->check($code, $id);
    }
}