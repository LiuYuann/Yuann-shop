<?php
namespace app\index\controller;
use think\Db;
class Index
{
    public function index()
    {
        $category=Db::query('SELECT DISTINCT pcname FROM itcast_category;');
        foreach ($category as $row){
            $kind=Db::query('SELECT cname,cid FROM itcast_category where pcname=:pcname;',["pcname"=>$row['pcname']]);
            $kinds[$row['pcname']]=$kind;
        }
        if (empty(session('user'))){
            session('user','请登陆');
        }
        if (!session('?mid')){
            session('sum',0);
            session('count',0);
        }
        session('kinds',$kinds);
        $newproduct=$this->newProduct();
        $featuredproduct=$this->featuredProduct();
        return view("Index",['new'=>$newproduct,'featured'=>$featuredproduct]);
    }
    
    public function newProduct()
    {
        $product=Db::table('itcast_goods')->where('status','yes')->order('turn','desc')->limit(6)->column('gid,gname,thumb,price');
        return $product;
    }
    public function featuredProduct()
    {
        $product=Db::table('itcast_goods')->orderRaw('rand()')->limit(16)->column('gid,gname,thumb,price');
        return $product;
    }
}
