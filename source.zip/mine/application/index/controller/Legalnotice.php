<?php
namespace app\index\controller;
class Legalnotice
{
    public function index()
    {
        return view('legalnotice');
    }
}