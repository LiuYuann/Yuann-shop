<?php
namespace app\index\controller;
use think\Db;
use think\Controller;
class Shopcart extends Controller
{
    public function index()
    {
        if (session('?mid')){
            $cart=Db::table('itcast_shopcart_goods')->where('mid',session('mid'))->select();
            $discount=Db::query('select itcast_discountgoods.gid,discount from itcast_discountgoods,itcast_shopcart_goods where itcast_discountgoods.gid=itcast_shopcart_goods.gid');
            $len=count($discount);
            for($i=0;$i<count($cart);$i++)
            {
                if($len)
                {
                    for($j=0;$j<count($discount);$j++)
                    {
                        if ($cart[$i]['gid']==$discount[$j]['gid'])
                        {
                            $cart[$i]['discount']=$discount[$j]['discount'];
                            $len=$len-1;
                            break;
                        }
                        else
                        {
                            $cart[$i]['discount']=0;
                        }
                    }
                }
                else
                {
                    $cart[$i]['discount']=0;
                }
            }
//             var_dump($cart);
            return view("shopcart",["cart"=>$cart]);
        }
        else{
            return $this->redirect('login/index');
        }
        
    }
    
    public function delcart()
    {
        $gid = input('get.gid');
        $mid = input('get.mid');
        $addTime=input('get.addTime');
        Db::table('itcast_shopcart')->where('mid=:mid and gid=:gid and addTime=:addTime')->bind(['mid'=>$mid,'gid'=>$gid,'addTime'=>$addTime])->delete();
        /* 获得购物车商品数量和总价 */
        $sum=0;
        $count=0;
        $freight=Db::table('itcast_address')->where('mid',session('mid'))->column('freight');
        $count=Db::table('itcast_shopcart')->where('mid',session('mid'))->count();
        $S=Db::table('itcast_shopcart_goods')->where('mid',session('mid'))->column('price,num');
        foreach ($S as $key=>$value)
        {
            $sum+=$key*$value;
        }
        $sum+=$count*$freight[0];
        session('count',$count);//商品种类
        session('sum',$sum);//总价
        $msg=[$count,$sum];
        echo json_encode($msg);
    }
    
    public function purchase()
    {
        if (session('?mid')){
            return view("purchase");
        }
        else{
            return $this->redirect('login/index');
        }   
    }
    public function dopurchase()
    {
      
        $gid = input('get.gid');
        $mid = input('get.mid');
        $price = input('get.price');
        $num= input('get.num');
        $time= date('Y-m-d H:i:s');
        $data = ['mid'=>$mid,'gid'=>$gid,'time'=>$time,'num'=>$num,'price'=>$price];
        $msg=Db::table('itcast_record')->insert($data);
        Db::table('itcast_shopcart')->where('mid',session('mid'))->delete();
        Db::table('itcast_goods')->where('gid',$gid)->setDec('stock',$num);//库存-
        Db::table('itcast_goods')->where('gid',$gid)->setInc('sales',$num);//销量+
        session('count',0);
        session('sum',0);
        echo json_encode($msg);
    }
}