<?php
namespace app\index\controller;
class Contact
{
    public function index()
    {
       return view('contact');
    }
    
}